import sys
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import json
import shutil

sys.stdout.reconfigure(encoding='utf-8')

# 1. Create a safe backup of the original workbook
shutil.copyfile('موهبة طيبة- طفولة مبكرة.xlsx', 'موهبة طيبة- طفولة مبكرة_نسخة_احتياطية.xlsx')
print('Backup created: موهبة طيبة- طفولة مبكرة_نسخة_احتياطية.xlsx')

wb = openpyxl.load_workbook('موهبة طيبة- طفولة مبكرة.xlsx')

# Load programs data
with open('programs_data.json', 'r', encoding='utf-8') as f:
    programs = json.load(f)

# Styles for Excel Dashboard
font_title = Font(name='Tajawal', size=16, bold=True, color='FFFFFF')
font_subtitle = Font(name='Tajawal', size=11, color='E2E8F0')
font_header = Font(name='Tajawal', size=11, bold=True, color='FFFFFF')
font_card_num = Font(name='Tajawal', size=20, bold=True, color='1E293B')
font_card_lbl = Font(name='Tajawal', size=10, bold=True, color='64748B')
font_bold = Font(name='Tajawal', size=10, bold=True, color='1E293B')
font_normal = Font(name='Tajawal', size=10, color='334155')
font_link = Font(name='Tajawal', size=10, bold=True, color='0284C7', underline='single')

fill_header = PatternFill(start_color='166534', end_color='166534', fill_type='solid') # Emerald Green
fill_sub = PatternFill(start_color='0F766E', end_color='0F766E', fill_type='solid') # Teal
fill_card = PatternFill(start_color='F8FAFC', end_color='F8FAFC', fill_type='solid') # Soft Slate
fill_card_border = PatternFill(start_color='E2E8F0', end_color='E2E8F0', fill_type='solid')
fill_th = PatternFill(start_color='1E3A8A', end_color='1E3A8A', fill_type='solid') # Deep Navy
fill_zebra = PatternFill(start_color='F1F5F9', end_color='F1F5F9', fill_type='solid')

thin_border = Border(
    left=Side(style='thin', color='CBD5E1'),
    right=Side(style='thin', color='CBD5E1'),
    top=Side(style='thin', color='CBD5E1'),
    bottom=Side(style='thin', color='CBD5E1')
)

align_center = Alignment(horizontal='center', vertical='center', wrap_text=True)
align_right = Alignment(horizontal='right', vertical='center', wrap_text=True)
align_left = Alignment(horizontal='left', vertical='center')

# Check if 'لوحة التحكم' already exists, if so remove or replace
if 'لوحة التحكم التفاعلية' in wb.sheetnames:
    del wb['لوحة التحكم التفاعلية']

ws_dash = wb.create_sheet('لوحة التحكم التفاعلية', 0)
ws_dash.views.sheetView[0].rightToLeft = True

# Set column widths
col_widths = {
    'A': 14, # ID
    'B': 26, # Name
    'C': 20, # Domain
    'D': 25, # Executor
    'E': 14, # Target
    'F': 14, # Status
    'G': 14, # Progress %
    'H': 24, # Web Link
    'I': 20  # QR Status
}
for col, w in col_widths.items():
    ws_dash.column_dimensions[col].width = w

# Row 1-2: Banner
ws_dash.merge_cells('A1:I1')
cell_title = ws_dash['A1']
cell_title.value = "الخطة التشغيلية السنوية | ابتدائية مواهب طيبة (طفولة مبكرة) - 1448هـ"
cell_title.font = font_title
cell_title.fill = fill_header
cell_title.alignment = align_center
ws_dash.row_dimensions[1].height = 36

ws_dash.merge_cells('A2:I2')
cell_sub = ws_dash['A2']
cell_sub.value = "لوحة التحكم والمتابعة التنفيذية • الإدارة العامة للتعليم بمنطقة المدينة المنورة • الرقم الوزاري: S-41529"
cell_sub.font = font_subtitle
cell_sub.fill = fill_sub
cell_sub.alignment = align_center
ws_dash.row_dimensions[2].height = 24

# Row 4-5: KPI Summary Cards
cards = [
    ('A4:B5', 'إجمالي البرامج', '13', '1E293B', 'F8FAFC'),
    ('C4:D5', 'نسبة الإنجاز العامة', '=ROUND(AVERAGE(G9:G21), 0)&"%"', '166534', 'DCFCE7'),
    ('E4:F5', 'البرامج المكتملة', '=COUNTIF(F9:F21, "مكتمل")', '059669', 'ECFDF5'),
    ('G4:G5', 'قيد التنفيذ', '=COUNTIF(F9:F21, "جارٍ التنفيذ")', '0284C7', 'F0F9FF'),
    ('H4:I5', 'لم يبدأ / متأخر', '=COUNTIF(F9:F21, "لم يبدأ")', 'D97706', 'FFFBEB')
]

for merge_range, label, val, text_color, bg_color in cards:
    ws_dash.merge_cells(merge_range)
    top_left = merge_range.split(':')[0]
    cell = ws_dash[top_left]
    cell.value = f"{label}\n{val}"
    cell.font = Font(name='Tajawal', size=13, bold=True, color=text_color)
    cell.fill = PatternFill(start_color=bg_color, end_color=bg_color, fill_type='solid')
    cell.alignment = align_center
    cell.border = thin_border

ws_dash.row_dimensions[4].height = 25
ws_dash.row_dimensions[5].height = 25

# Row 7: Section Header
ws_dash.merge_cells('A7:I7')
ws_dash['A7'].value = "مصفوفة البرامج والمبادرات وشواهد التنفيذ (أزرار الانتقال المباشر للويب)"
ws_dash['A7'].font = Font(name='Tajawal', size=12, bold=True, color='FFFFFF')
ws_dash['A7'].fill = fill_th
ws_dash['A7'].alignment = align_center
ws_dash.row_dimensions[7].height = 26

# Row 8: Table Headers
headers = ['المعرّف', 'البرنامج / المبادرة', 'المجال', 'مسؤول التنفيذ', 'المستهدف', 'حالة التنفيذ', 'نسبة الإنجاز', 'رابط الشواهد (ويب)', 'الباركود (QR)']
for idx, h in enumerate(headers, 1):
    col_letter = get_column_letter(idx)
    c = ws_dash[f'{col_letter}8']
    c.value = h
    c.font = font_header
    c.fill = PatternFill(start_color='334155', end_color='334155', fill_type='solid')
    c.alignment = align_center
    c.border = thin_border
ws_dash.row_dimensions[8].height = 24

# Populate Rows 9 to 21
for idx, p in enumerate(programs, 9):
    ws_dash.row_dimensions[idx].height = 22
    is_even = (idx % 2 == 0)
    row_fill = fill_zebra if is_even else PatternFill(fill_type=None)
    
    # Col A: ID
    cA = ws_dash[f'A{idx}']
    cA.value = p['id']
    cA.font = font_bold
    cA.alignment = align_center
    cA.border = thin_border
    if is_even: cA.fill = row_fill
    
    # Col B: Name
    cB = ws_dash[f'B{idx}']
    cB.value = p['name']
    cB.font = font_bold
    cB.alignment = align_right
    cB.border = thin_border
    if is_even: cB.fill = row_fill
    
    # Col C: Domain
    cC = ws_dash[f'C{idx}']
    cC.value = p['domain']
    cC.font = font_normal
    cC.alignment = align_right
    cC.border = thin_border
    if is_even: cC.fill = row_fill
    
    # Col D: Executor
    cD = ws_dash[f'D{idx}']
    cD.value = p['executor']
    cD.font = font_normal
    cD.alignment = align_right
    cD.border = thin_border
    if is_even: cD.fill = row_fill
    
    # Col E: Target
    cE = ws_dash[f'E{idx}']
    cE.value = p['target_kpi'] or '95%'
    cE.font = font_normal
    cE.alignment = align_center
    cE.border = thin_border
    if is_even: cE.fill = row_fill
    
    # Col F: Status
    cF = ws_dash[f'F{idx}']
    cF.value = p['status']
    cF.font = font_bold
    cF.alignment = align_center
    cF.border = thin_border
    if is_even: cF.fill = row_fill
    
    # Col G: Progress
    cG = ws_dash[f'G{idx}']
    cG.value = int(p['progress'])
    cG.font = font_bold
    cG.alignment = align_center
    cG.border = thin_border
    cG.number_format = '0"%"'
    if is_even: cG.fill = row_fill
    
    # Col H: Web Link Button / Hyperlink
    cH = ws_dash[f'H{idx}']
    web_url = p['barcode_link']
    cH.value = f'=HYPERLINK("{web_url}", "🔗 فتح الشواهد في الويب")'
    cH.font = font_link
    cH.alignment = align_center
    cH.border = thin_border
    if is_even: cH.fill = row_fill
    
    # Col I: QR Code Status
    cI = ws_dash[f'I{idx}']
    cI.value = "جاهز في لوحة الويب"
    cI.font = font_normal
    cI.alignment = align_center
    cI.border = thin_border
    if is_even: cI.fill = row_fill

# Also update sheet 'متابعة التنفيذ' Column K with web links
ws_follow = wb['متابعة التنفيذ']
for r_idx in range(3, 16):
    pid_cell = ws_follow.cell(row=r_idx, column=13)
    pid = pid_cell.value
    prog_match = next((p for p in programs if p['id'] == pid), None)
    if prog_match:
        link_cell = ws_follow.cell(row=r_idx, column=11)
        link_cell.value = f'=HYPERLINK("{prog_match["barcode_link"]}", "رابط الشواهد")'
        link_cell.font = font_link

wb.save('موهبة طيبة- طفولة مبكرة.xlsx')
print('Successfully enhanced workbook with interactive dashboard sheet!')
