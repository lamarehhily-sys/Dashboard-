import os, shutil

# Target directory: files
target_folder = 'files'
os.makedirs(target_folder, exist_ok=True)

# Items to move into files/
items = os.listdir('.')
for item in items:
    if item in ['index.html', 'files', '.git', '.gemini']:
        continue
    dest = os.path.join(target_folder, item)
    if os.path.exists(dest):
        if os.path.isdir(dest):
            shutil.rmtree(dest)
        else:
            os.remove(dest)
    shutil.move(item, target_folder)

print('Moved all files into files/ successfully. Only index.html and files/ remain at the root.')
