import sys, openpyxl

sys.stdout.reconfigure(encoding='utf-8')

wb = openpyxl.load_workbook('موهبة طيبة- طفولة مبكرة.xlsx')

links_dict = {
    'PRG-001': 'https://drive.google.com/drive/folders/1IAGfkc8uyFu08bl5SlCZKucKUfm0I1hh',
    'PRG-002': 'https://drive.google.com/drive/folders/1gySiHnNUSMpnI23y7hTF1RPaXxRtAiSX',
    'PRG-003': 'https://drive.google.com/drive/folders/10bvK-cwoc_5hjGd-zURDKCQPLp7-Bv2b',
    'PRG-004': 'https://drive.google.com/drive/folders/1VYx17kud8XBdoyYTGpq9hZNGSrqBDDWB',
    'PRG-005': 'https://drive.google.com/drive/folders/1WjU6c6Re_UoJLJE_V5v7z5AWpbgh_ADV',
    'PRG-006': 'https://drive.google.com/drive/folders/14t4LyPkASwai7KzjnxCXg3Vg0yuTfHxw',
    'PRG-007': 'https://drive.google.com/drive/folders/1DVaZG88o8J-ZqzgYm1VAP6FcKYG0IzgG',
    'PRG-008': 'https://drive.google.com/drive/folders/1VE3Bde-op7TXcfqp3zSOzKHRqR-VC4Eu',
    'PRG-009': 'https://drive.google.com/drive/folders/1A7_KEpVgvLHUYjD1noIpf73ISvDZs_n_ ',
    'PRG-010': 'https://drive.google.com/drive/folders/1QFdGpmvNc6FhLejFTaBMPnPz3Ep0ybLP',
    'PRG-011': 'https://drive.google.com/drive/folders/1YJ3LgC3jGSeRwxWISMIuESaNqMV_ccKu',
    'PRG-012': 'https://drive.google.com/drive/folders/1A7_KEpVgvLHUYjD1noIpf73ISvDZs_n_',
    'PRG-013': 'https://drive.google.com/drive/folders/1FJwhTjTVs2l21KraXknKISJOC8MyITAU'
}

# Update sheet 'البرامج والمبادرات'
if 'البرامج والمبادرات' in wb.sheetnames:
    ws_prog = wb['البرامج والمبادرات']
    for r in range(3, ws_prog.max_row + 1):
        pid = ws_prog.cell(row=r, column=18).value
        if pid and pid in links_dict:
            ws_prog.cell(row=r, column=16).value = links_dict[pid]

# Update sheet 'متابعة التنفيذ'
if 'متابعة التنفيذ' in wb.sheetnames:
    ws_follow = wb['متابعة التنفيذ']
    for r in range(3, ws_follow.max_row + 1):
        pid = ws_follow.cell(row=r, column=13).value
        if pid and pid in links_dict:
            ws_follow.cell(row=r, column=11).value = links_dict[pid]

# Update sheet 'لوحة التحكم التفاعلية'
if 'لوحة التحكم التفاعلية' in wb.sheetnames:
    ws_dash = wb['لوحة التحكم التفاعلية']
    for r in range(9, 22):
        pid = ws_dash.cell(row=r, column=1).value
        if pid and pid in links_dict:
            url = links_dict[pid]
            ws_dash.cell(row=r, column=8).value = f'=HYPERLINK("{url}", "🔗 فتح الشواهد في الويب")'

wb.save('موهبة طيبة- طفولة مبكرة.xlsx')
print('Excel successfully updated with exact Google Drive links from links.docx!')
