import json

with open('programs_data.json', 'r', encoding='utf-8') as f:
    programs = json.load(f)

html_template = f'''<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم الخطة التشغيلية | ابتدائية مواهب طيبة (طفولة مبكرة)</title>
    
    <!-- Local & CDN CSS -->
    <link rel="stylesheet" href="libs/tailwind.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Local & CDN JS -->
    <script src="libs/chart.umd.min.js"></script>
    <script src="libs/qrcode.min.js"></script>
    
    <style>
        :root {{
            --primary: #15803d;
            --primary-dark: #166534;
            --primary-light: #dcfce7;
            --accent: #0f766e;
            --bg-calm: #f8fafc;
        }}
        body {{
            font-family: 'Tajawal', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: #f8fafc;
            color: #1e293b;
            scroll-behavior: smooth;
        }}
        /* Custom scrollbar */
        ::-webkit-scrollbar {{
            width: 8px;
            height: 8px;
        }}
        ::-webkit-scrollbar-track {{
            background: #f1f5f9;
        }}
        ::-webkit-scrollbar-thumb {{
            background: #cbd5e1;
            border-radius: 4px;
        }}
        ::-webkit-scrollbar-thumb:hover {{
            background: #94a3b8;
        }}
        .card-soft {{
            background: #ffffff;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02), 0 2px 4px -2px rgba(0, 0, 0, 0.02);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }}
        .card-soft:hover {{
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -4px rgba(0, 0, 0, 0.02);
        }}
        .gradient-calm-header {{
            background: linear-gradient(135deg, #134e4a 0%, #166534 50%, #1e3a8a 100%);
        }}
        .gauge-circle {{
            transition: stroke-dashoffset 0.8s ease-in-out;
        }}
        @keyframes scaleUp {{
            from {{ transform: scale(0.95); opacity: 0; }}
            to {{ transform: scale(1); opacity: 1; }}
        }}
        .animate-scaleUp {{
            animation: scaleUp 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }}
        @media print {{
            .no-print {{
                display: none !important;
            }}
            body {{
                background: white !important;
            }}
            .card-soft {{
                box-shadow: none !important;
                border: 1px solid #cbd5e1 !important;
                break-inside: avoid;
            }}
        }}
    </style>
</head>
<body class="min-h-screen text-slate-800 flex flex-col justify-between">

    <!-- ===================== 1. HEADER SECTION ===================== -->
    <header class="gradient-calm-header text-white shadow-lg sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
            <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                
                <!-- School & Ministry Brand -->
                <div class="flex items-center gap-4 w-full md:w-auto justify-between md:justify-start">
                    <div class="flex items-center gap-3">
                        <!-- Ministry of Education Logo -->
                        <div class="bg-white/95 p-1.5 rounded-xl shadow-md flex items-center justify-center h-14 w-20">
                            <img src="assets/page3_Image31.png" alt="شعار وزارة التعليم" class="h-full object-contain" onerror="this.parentElement.innerHTML='<span class=\"text-xs text-emerald-800 font-bold text-center\">وزارة التعليم</span>'">
                        </div>

                        <!-- School Emblem & Title -->
                        <div>
                            <div class="flex items-center gap-2">
                                <span class="px-2 py-0.5 text-xs font-semibold bg-emerald-500/30 text-emerald-100 rounded-full border border-emerald-400/40">الرقم الوزاري: S-41529</span>
                                <span class="px-2 py-0.5 text-xs font-semibold bg-blue-500/30 text-blue-100 rounded-full border border-blue-400/40">1448هـ</span>
                            </div>
                            <h1 class="text-xl sm:text-2xl font-black tracking-tight mt-0.5">ابتدائية مواهب طيبة <span class="text-emerald-300 text-lg font-medium">(طفولة مبكرة)</span></h1>
                            <p class="text-xs text-slate-200">الإدارة العامة للتعليم بمنطقة المدينة المنورة • مكتب تعليم العزيزية</p>
                        </div>
                    </div>
                </div>

                <!-- School Quick Metrics Badge & Actions -->
                <div class="flex flex-wrap items-center justify-center md:justify-end gap-2 w-full md:w-auto no-print">
                    <div class="hidden xl:flex items-center gap-3 text-xs bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-xl border border-white/15">
                        <div class="text-center"><span class="block font-bold text-white">421</span><span class="text-slate-300 text-[10px]">طالبة</span></div>
                        <div class="w-px h-6 bg-white/20"></div>
                        <div class="text-center"><span class="block font-bold text-white">34</span><span class="text-slate-300 text-[10px]">معلمة</span></div>
                        <div class="w-px h-6 bg-white/20"></div>
                        <div class="text-center"><span class="block font-bold text-white">15</span><span class="text-slate-300 text-[10px]">فصلاً</span></div>
                        <div class="w-px h-6 bg-white/20"></div>
                        <div class="text-center"><span class="block font-bold text-white">عيدة الرشيدي</span><span class="text-slate-300 text-[10px]">مديرة المدرسة</span></div>
                    </div>

                    <button onclick="window.print()" class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white/15 hover:bg-white/25 rounded-lg border border-white/20 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                        <span>طباعة اللوحة</span>
                    </button>

                    <button onclick="exportDataToCSV()" class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg shadow-sm transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        <span>تصدير Excel</span>
                    </button>

                    <button onclick="resetData()" title="استعادة البيانات الأصلية" class="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- ===================== MAIN CONTENT WRAPPER ===================== -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 w-full flex-grow">

        <!-- ===================== 2. DAILY TRACKING & QUICK FILTERS ===================== -->
        <section class="card-soft p-4 rounded-2xl">
            <div class="flex flex-col lg:flex-row items-center justify-between gap-4">
                
                <!-- Date & Daily Tracker Info -->
                <div class="flex items-center gap-3 w-full lg:w-auto">
                    <div class="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="text-xs font-bold text-emerald-800 uppercase tracking-wider">متابعة يومية مستمرة</span>
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-100 text-emerald-800">مُحدّث لحظياً</span>
                        </div>
                        <p class="text-sm text-slate-600 font-medium" id="currentDateDisplay">اليوم: متابعة خطة الفصل الدراسي الحالي</p>
                    </div>
                </div>

                <!-- Instant Search & Quick View Toggle -->
                <div class="flex items-center gap-3 w-full lg:w-auto justify-end flex-wrap sm:flex-nowrap">
                    <div class="relative w-full sm:w-64">
                        <input type="text" id="searchInput" oninput="applyFilters()" placeholder="بحث عن برنامج، منفذ، أو مجال..." 
                               class="w-full pl-9 pr-9 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition">
                        <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        </div>
                        <button onclick="document.getElementById('searchInput').value=''; applyFilters();" class="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 hover:text-slate-600">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        </button>
                    </div>

                    <!-- View Switcher -->
                    <div class="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs shrink-0">
                        <button id="viewCardsBtn" onclick="switchView('cards')" class="px-3 py-1.5 rounded-lg font-bold bg-white text-emerald-800 shadow-xs flex items-center gap-1.5 transition">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                            <span>بطاقات</span>
                        </button>
                        <button id="viewTableBtn" onclick="switchView('table')" class="px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                            <span>جدول</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Filter Chips (Domains & Status) -->
            <div class="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                <!-- Domains filter -->
                <div class="flex flex-wrap items-center gap-1.5">
                    <span class="text-slate-500 font-bold ml-1">المجال:</span>
                    <button onclick="filterDomain('all')" class="domain-chip px-2.5 py-1 rounded-lg font-bold bg-emerald-700 text-white transition" data-domain="all">الكل (13)</button>
                    <button onclick="filterDomain('الإدارة المدرسية')" class="domain-chip px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition" data-domain="الإدارة المدرسية">الإدارة المدرسية</button>
                    <button onclick="filterDomain('نواتج التعلم')" class="domain-chip px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition" data-domain="نواتج التعلم">نواتج التعلم</button>
                    <button onclick="filterDomain('التعليم والتعلم')" class="domain-chip px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition" data-domain="التعليم والتعلم">التعليم والتعلم</button>
                    <button onclick="filterDomain('البيئة المدرسية')" class="domain-chip px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition" data-domain="البيئة المدرسية">البيئة المدرسية</button>
                </div>

                <!-- Status filter -->
                <div class="flex flex-wrap items-center gap-1.5">
                    <span class="text-slate-500 font-bold ml-1">الحالة:</span>
                    <button onclick="filterStatus('all')" class="status-chip px-2.5 py-1 rounded-lg font-bold bg-slate-800 text-white transition" data-status="all">الجميع</button>
                    <button onclick="filterStatus('مكتمل')" class="status-chip px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition" data-status="مكتمل">مكتمل (100%)</button>
                    <button onclick="filterStatus('جارٍ التنفيذ')" class="status-chip px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 transition" data-status="جارٍ التنفيذ">جارٍ التنفيذ</button>
                    <button onclick="filterStatus('لم يبدأ')" class="status-chip px-2.5 py-1 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 transition" data-status="لم يبدأ">لم يبدأ</button>
                </div>
            </div>
        </section>

        <!-- ===================== 3. EXECUTIVE KPI METRICS ===================== -->
        <section class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            
            <!-- Overall Progress Gauge Card -->
            <div class="col-span-2 md:col-span-3 lg:col-span-2 card-soft p-4 rounded-2xl flex items-center justify-between bg-gradient-to-br from-emerald-50/70 via-white to-white border-emerald-200/80">
                <div class="space-y-1">
                    <span class="text-xs font-bold text-emerald-800 uppercase tracking-wide">نسبة إنجاز الخطة الإجمالية</span>
                    <h3 class="text-3xl font-black text-emerald-950"><span id="kpiOverallPercent">0</span><span class="text-lg text-emerald-700 font-bold mr-1">%</span></h3>
                    <p class="text-xs text-slate-500" id="kpiProgressSubtext">معدل متوسط تقدم البرامج الـ 13</p>
                </div>
                <!-- Circular SVG Progress -->
                <div class="relative w-20 h-20 shrink-0">
                    <svg class="w-20 h-20 -rotate-90" viewBox="0 0 36 36">
                        <path class="text-emerald-100" stroke-width="3.5" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                        <path id="gaugeProgressPath" class="text-emerald-600 gauge-circle" stroke-dasharray="0, 100" stroke-width="3.5" stroke-linecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div class="absolute inset-0 flex items-center justify-center font-black text-xs text-emerald-800">
                        <span id="gaugeText">0%</span>
                    </div>
                </div>
            </div>

            <!-- Total Programs Card -->
            <div class="card-soft p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-semibold text-slate-600">إجمالي البرامج</span>
                    <div class="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                    </div>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-slate-800" id="kpiTotalPrograms">13</div>
                    <span class="text-[11px] text-slate-500">برامج ومبادرات معتمدة</span>
                </div>
            </div>

            <!-- Completed Programs Card -->
            <div class="card-soft p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-semibold text-emerald-700">مكتمل</span>
                    <div class="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-emerald-600" id="kpiCompletedPrograms">0</div>
                    <span class="text-[11px] text-slate-500">نسبة إنجاز 100%</span>
                </div>
            </div>

            <!-- In Progress Card -->
            <div class="card-soft p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-semibold text-blue-700">جارٍ التنفيذ</span>
                    <div class="p-1.5 bg-blue-50 text-blue-600 rounded-lg">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-blue-600" id="kpiInProgressPrograms">0</div>
                    <span class="text-[11px] text-slate-500">قيد المتابعة والعمل</span>
                </div>
            </div>

            <!-- Not Started / Pending Card -->
            <div class="card-soft p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-semibold text-amber-700">لم يبدأ / متأخر</span>
                    <div class="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                    </div>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-amber-600" id="kpiPendingPrograms">13</div>
                    <span class="text-[11px] text-slate-500">بانتظار انطلاق التنفيذ</span>
                </div>
            </div>

        </section>

        <!-- ===================== 4. EXECUTORS COMPARISON SECTION ===================== -->
        <section class="card-soft p-5 rounded-2xl">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 mb-4 border-b border-slate-100 gap-2">
                <div>
                    <div class="flex items-center gap-2">
                        <div class="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                        </div>
                        <h2 class="text-base font-bold text-slate-800">المقارنة بين مسؤولي ومنفذي البرامج</h2>
                    </div>
                    <p class="text-xs text-slate-500 mt-0.5">تحليل وتوزيع البرامج ومعدل الإنجاز المحقق لكل جهة ومسؤول تنفيذ</p>
                </div>
                <span class="text-xs text-slate-400 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200/60">انقر على أي مسؤول في القائمة لتصفية برامجه فورياً</span>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                <!-- Chart Container -->
                <div class="lg:col-span-7 bg-slate-50/70 p-4 rounded-xl border border-slate-200/60">
                    <div class="h-64 sm:h-72 w-full relative">
                        <canvas id="executorsChart"></canvas>
                    </div>
                </div>

                <!-- Executor Mini Cards List -->
                <div class="lg:col-span-5 space-y-2.5 max-h-72 overflow-y-auto pr-1" id="executorsListContainer">
                    <!-- Populated dynamically via JS -->
                </div>
            </div>
        </section>

        <!-- ===================== 5. OPERATIONAL PLAN PROGRAMS HUB ===================== -->
        <section class="space-y-4">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                    <h2 class="text-lg font-black text-slate-800 flex items-center gap-2">
                        <span>خطة البرامج والمبادرات وشواهد التنفيذ</span>
                        <span class="text-xs font-semibold px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full" id="programsCountBadge">13 برنامج</span>
                    </h2>
                    <p class="text-xs text-slate-500 mt-0.5">كل برنامج مزود بزر للانتقال المباشر للويب ومولد باركود الشواهد (QR Code)</p>
                </div>

                <div class="flex items-center gap-2">
                    <button onclick="openAddProgramModal()" class="px-3.5 py-1.5 text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl shadow-xs flex items-center gap-1.5 transition no-print">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        <span>إضافة برنامج جديد</span>
                    </button>
                </div>
            </div>

            <!-- CARDS VIEW (Default) -->
            <div id="cardsViewContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Generated by JS -->
            </div>

            <!-- TABLE VIEW -->
            <div id="tableViewContainer" class="card-soft rounded-2xl overflow-hidden hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 text-right text-xs">
                        <thead class="bg-slate-50 text-slate-600 font-bold">
                            <tr>
                                <th class="py-3 px-3">المعرّف</th>
                                <th class="py-3 px-4">البرنامج والمبادرة</th>
                                <th class="py-3 px-3">المجال</th>
                                <th class="py-3 px-3">مسؤول التنفيذ</th>
                                <th class="py-3 px-3">المستهدف</th>
                                <th class="py-3 px-3">الحالة</th>
                                <th class="py-3 px-3 text-center">نسبة الإنجاز</th>
                                <th class="py-3 px-3 text-center">الرابط والويب</th>
                                <th class="py-3 px-3 text-center">الباركود (QR)</th>
                            </tr>
                        </thead>
                        <tbody id="tableBodyContainer" class="divide-y divide-slate-100 bg-white">
                            <!-- Generated by JS -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

    </main>

    <!-- ===================== FOOTER ===================== -->
    <footer class="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 mt-8">
        <div class="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p>الخطة التشغيلية السنوية • ابتدائية مواهب طيبة (طفولة مبكرة) • العام الدراسي 1448هـ</p>
            <p class="text-slate-400">نظام لوحة التحكم والمتابعة المترابطة | جميع الحقوق محفوظة</p>
        </div>
    </footer>

    <!-- ===================== MODAL: QR CODE & EVIDENCE LINK ===================== -->
    <div id="qrModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-scaleUp">
            
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2">
                    <div class="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
                    </div>
                    <div>
                        <h3 class="text-base font-bold text-slate-800" id="modalProgramName">باركود شواهد البرنامج</h3>
                        <span class="text-xs text-slate-500" id="modalProgramId">PRG-000</span>
                    </div>
                </div>
                <button onclick="closeQrModal()" class="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            <!-- QR Container -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col items-center justify-center space-y-2">
                <div id="qrcodeCanvas" class="bg-white p-3 rounded-xl shadow-xs border border-slate-200"></div>
                <p class="text-[11px] text-slate-500 font-medium text-center">امسح الباركود بكاميرا الجوال للانتقال لملف الشواهد المباشر</p>
            </div>

            <!-- Web Link Input & Update -->
            <div class="space-y-1.5">
                <label class="block text-xs font-bold text-slate-700">رابط الشواهد على الويب (Google Drive / OneDrive / منصة):</label>
                <div class="flex items-center gap-2">
                    <input type="url" id="modalLinkInput" class="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50" placeholder="https://...">
                    <button onclick="saveModalLink()" class="px-3 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl transition">حفظ الرابط</button>
                </div>
            </div>

            <!-- Modal Action Buttons -->
            <div class="grid grid-cols-2 gap-2 pt-2">
                <button onclick="openModalWebLink()" class="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                    <span>فتح في الويب</span>
                </button>
                <button onclick="downloadQrImage()" class="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-900 text-white rounded-xl transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    <span>تنزيل الباركود PNG</span>
                </button>
            </div>
        </div>
    </div>

    <!-- ===================== MODAL: ADD NEW PROGRAM ===================== -->
    <div id="addProgramModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
        <div class="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 class="text-base font-bold text-slate-800">إضافة برنامج أو مبادرة تشغيلية جديدة</h3>
                <button onclick="closeAddProgramModal()" class="text-slate-400 hover:text-slate-600 p-1 rounded-lg">✕</button>
            </div>

            <form id="addProgramForm" onsubmit="submitNewProgram(event)" class="space-y-3 text-xs">
                <div>
                    <label class="block font-bold text-slate-700 mb-1">اسم البرنامج / المبادرة:</label>
                    <input type="text" id="newProgName" required class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white" placeholder="مثال: تعزيز القراءة الإثرائية">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">المجال:</label>
                        <select id="newProgDomain" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50">
                            <option value="الإدارة المدرسية">الإدارة المدرسية</option>
                            <option value="نواتج التعلم">نواتج التعلم</option>
                            <option value="التعليم والتعلم">التعليم والتعلم</option>
                            <option value="البيئة المدرسية">البيئة المدرسية</option>
                        </select>
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">مسؤول التنفيذ:</label>
                        <input type="text" id="newProgExecutor" required class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="مثال: الموجهة الطلابية">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">المستهدف والمؤشر:</label>
                        <input type="text" id="newProgTarget" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="مثال: 95% من الطالبات">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">الجهة المساندة:</label>
                        <input type="text" id="newProgSupporter" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="مثال: رائدة النشاط / المعلمات">
                    </div>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">رابط الشواهد على الويب:</label>
                    <input type="url" id="newProgLink" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="https://drive.google.com/...">
                </div>

                <div class="pt-2 flex justify-end gap-2">
                    <button type="button" onclick="closeAddProgramModal()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition">إلغاء</button>
                    <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition">إضافة البرنامج</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===================== TOAST NOTIFICATION ===================== -->
    <div id="toastBox" class="fixed bottom-5 left-5 z-50 bg-slate-900 text-white text-xs px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 transform translate-y-20 opacity-0 transition-all duration-300 pointer-events-none">
        <span id="toastMsg">تم الحفظ بنجاح</span>
    </div>

    <!-- ===================== JAVASCRIPT LOGIC ===================== -->
    <script>
        // Initial Dataset from Excel
        const INITIAL_PROGRAMS = ''' + json.dumps(programs, ensure_ascii=False) + ''';

        let programsData = [];
        let activeDomain = 'all';
        let activeStatus = 'all';
        let activeExecutor = 'all';
        let currentView = 'cards';
        let activeModalProgId = null;
        let qrCodeInstance = null;
        let comparisonChart = null;

        // Initialize App
        document.addEventListener('DOMContentLoaded', () => {
            loadProgramsData();
            updateCurrentDate();
            renderDashboard();
        });

        function loadProgramsData() {
            const saved = localStorage.getItem('mawahib_operational_plan_v1');
            if (saved) {
                try {
                    programsData = JSON.parse(saved);
                } catch(e) {
                    programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
                }
            } else {
                programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
            }
        }

        function saveData() {
            localStorage.setItem('mawahib_operational_plan_v1', JSON.stringify(programsData));
        }

        function resetData() {
            if (confirm('هل ترغب حقاً في إعادة ضبط البيانات إلى القيم الأصلية من ملف الإكسل؟')) {
                localStorage.removeItem('mawahib_operational_plan_v1');
                programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
                renderDashboard();
                showToast('تمت استعادة البيانات الأصلية بنجاح');
            }
        }

        function updateCurrentDate() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            const formatted = now.toLocaleDateString('ar-SA', options);
            document.getElementById('currentDateDisplay').textContent = formatted + ' • العام الدراسي 1448هـ';
        }

        function renderDashboard() {
            renderKPIs();
            renderExecutorsComparison();
            renderProgramsList();
        }

        // ===================== KPI CALCULATIONS =====================
        function renderKPIs() {
            const total = programsData.length;
            let sumProgress = 0;
            let completed = 0;
            let inProgress = 0;
            let pending = 0;

            programsData.forEach(p => {
                const prog = parseInt(p.progress) || 0;
                sumProgress += prog;
                if (prog === 100 || p.status === 'مكتمل') {
                    completed++;
                } else if (prog > 0 || p.status === 'جارٍ التنفيذ') {
                    inProgress++;
                } else {
                    pending++;
                }
            });

            const avgProgress = total > 0 ? Math.round(sumProgress / total) : 0;

            document.getElementById('kpiTotalPrograms').textContent = total;
            document.getElementById('kpiCompletedPrograms').textContent = completed;
            document.getElementById('kpiInProgressPrograms').textContent = inProgress;
            document.getElementById('kpiPendingPrograms').textContent = pending;
            document.getElementById('kpiOverallPercent').textContent = avgProgress;
            document.getElementById('gaugeText').textContent = avgProgress + '%';

            // SVG Circular Gauge stroke
            const path = document.getElementById('gaugeProgressPath');
            if (path) {
                path.setAttribute('stroke-dasharray', `${avgProgress}, 100`);
            }
        }

        // ===================== EXECUTORS COMPARISON =====================
        function renderExecutorsComparison() {
            const execMap = {};
            programsData.forEach(p => {
                const ex = (p.executor || 'غير محدد').trim();
                if (!execMap[ex]) {
                    execMap[ex] = { count: 0, sumProgress: 0, programs: [] };
                }
                execMap[ex].count += 1;
                execMap[ex].sumProgress += (parseInt(p.progress) || 0);
                execMap[ex].programs.push(p);
            });

            const labels = [];
            const counts = [];
            const averages = [];
            const sortedExecs = [];

            for (const [ex, data] of Object.entries(execMap)) {
                const avg = Math.round(data.sumProgress / data.count);
                sortedExecs.push({ name: ex, count: data.count, avgProgress: avg });
            }

            // Sort by count and avg
            sortedExecs.sort((a, b) => b.count - a.count);

            sortedExecs.forEach(item => {
                labels.push(item.name.length > 20 ? item.name.substring(0, 18) + '...' : item.name);
                counts.push(item.count);
                averages.push(item.avgProgress);
            });

            // Render Chart.js
            const ctx = document.getElementById('executorsChart');
            if (ctx) {
                if (comparisonChart) {
                    comparisonChart.destroy();
                }
                comparisonChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'عدد البرامج المسندة',
                                data: counts,
                                backgroundColor: '#10b981',
                                borderRadius: 6,
                                yAxisID: 'y'
                            },
                            {
                                label: 'متوسط نسبة الإنجاز (%)',
                                data: averages,
                                backgroundColor: '#3b82f6',
                                borderRadius: 6,
                                yAxisID: 'y1'
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: {
                            mode: 'index',
                            intersect: false,
                        },
                        plugins: {
                            legend: {
                                position: 'top',
                                labels: {
                                    font: { family: 'Tajawal', size: 11 },
                                    boxWidth: 12
                                }
                            },
                            tooltip: {
                                rtl: true,
                                titleFont: { family: 'Tajawal' },
                                bodyFont: { family: 'Tajawal' }
                            }
                        },
                        scales: {
                            x: {
                                ticks: { font: { family: 'Tajawal', size: 10 } },
                                grid: { display: false }
                            },
                            y: {
                                type: 'linear',
                                display: true,
                                position: 'right',
                                title: { display: true, text: 'عدد البرامج', font: { family: 'Tajawal', size: 10 } },
                                min: 0,
                                ticks: { stepSize: 1 }
                            },
                            y1: {
                                type: 'linear',
                                display: true,
                                position: 'left',
                                title: { display: true, text: 'الإنجاز %', font: { family: 'Tajawal', size: 10 } },
                                min: 0,
                                max: 100,
                                grid: { drawOnChartArea: false }
                            }
                        }
                    }
                });
            }

            // Render Mini Executor Cards
            const container = document.getElementById('executorsListContainer');
            if (container) {
                container.innerHTML = sortedExecs.map(ex => {
                    const isActive = activeExecutor === ex.name;
                    return `
                        <div onclick="filterExecutor('${ex.name}')" 
                             class="p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between text-xs ${
                                 isActive ? 'bg-emerald-50 border-emerald-500 shadow-xs' : 'bg-white hover:bg-slate-50 border-slate-200'
                             }">
                            <div class="flex items-center gap-2.5">
                                <div class="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-slate-700 shrink-0">
                                    ${ex.name.charAt(0)}
                                </div>
                                <div>
                                    <h4 class="font-bold text-slate-800 line-clamp-1">${ex.name}</h4>
                                    <span class="text-[11px] text-slate-500">${ex.count} برامج مسندة</span>
                                </div>
                            </div>
                            <div class="text-left">
                                <span class="font-bold ${ex.avgProgress >= 80 ? 'text-emerald-600' : (ex.avgProgress > 0 ? 'text-blue-600' : 'text-slate-400')}">
                                    ${ex.avgProgress}%
                                </span>
                                <div class="w-16 bg-slate-100 h-1.5 rounded-full mt-1 overflow-hidden">
                                    <div class="bg-emerald-500 h-full rounded-full" style="width: ${ex.avgProgress}%"></div>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
            }
        }

        // ===================== FILTERS & SEARCH =====================
        function filterDomain(dom) {
            activeDomain = dom;
            document.querySelectorAll('.domain-chip').forEach(c => {
                if (c.getAttribute('data-domain') === dom) {
                    c.className = 'domain-chip px-2.5 py-1 rounded-lg font-bold bg-emerald-700 text-white transition';
                } else {
                    c.className = 'domain-chip px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition';
                }
            });
            renderProgramsList();
        }

        function filterStatus(stat) {
            activeStatus = stat;
            document.querySelectorAll('.status-chip').forEach(c => {
                if (c.getAttribute('data-status') === stat) {
                    c.className = 'status-chip px-2.5 py-1 rounded-lg font-bold bg-slate-800 text-white transition';
                } else {
                    c.className = 'status-chip px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition';
                }
            });
            renderProgramsList();
        }

        function filterExecutor(exName) {
            if (activeExecutor === exName) {
                activeExecutor = 'all'; // toggle off
            } else {
                activeExecutor = exName;
            }
            renderExecutorsComparison();
            renderProgramsList();
        }

        function applyFilters() {
            renderProgramsList();
        }

        function getFilteredPrograms() {
            const query = (document.getElementById('searchInput')?.value || '').trim().toLowerCase();

            return programsData.filter(p => {
                // Domain match
                if (activeDomain !== 'all') {
                    if (!p.domain || !p.domain.includes(activeDomain)) return false;
                }

                // Status match
                if (activeStatus !== 'all') {
                    const prog = parseInt(p.progress) || 0;
                    if (activeStatus === 'مكتمل' && prog < 100 && p.status !== 'مكتمل') return false;
                    if (activeStatus === 'جارٍ التنفيذ' && (prog === 0 || prog === 100)) return false;
                    if (activeStatus === 'لم يبدأ' && prog > 0) return false;
                }

                // Executor match
                if (activeExecutor !== 'all') {
                    if ((p.executor || '').trim() !== activeExecutor) return false;
                }

                // Query search
                if (query) {
                    const searchStr = `${p.id} ${p.name} ${p.domain} ${p.executor} ${p.detailed_goal} ${p.indicator}`.toLowerCase();
                    if (!searchStr.includes(query)) return false;
                }

                return true;
            });
        }

        // ===================== VIEW SWITCHER =====================
        function switchView(view) {
            currentView = view;
            const cardsBtn = document.getElementById('viewCardsBtn');
            const tableBtn = document.getElementById('viewTableBtn');
            const cardsContainer = document.getElementById('cardsViewContainer');
            const tableContainer = document.getElementById('tableViewContainer');

            if (view === 'cards') {
                cardsBtn.className = 'px-3 py-1.5 rounded-lg font-bold bg-white text-emerald-800 shadow-xs flex items-center gap-1.5 transition';
                tableBtn.className = 'px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition';
                cardsContainer.classList.remove('hidden');
                tableContainer.classList.add('hidden');
            } else {
                tableBtn.className = 'px-3 py-1.5 rounded-lg font-bold bg-white text-emerald-800 shadow-xs flex items-center gap-1.5 transition';
                cardsBtn.className = 'px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition';
                cardsContainer.classList.add('hidden');
                tableContainer.classList.remove('hidden');
            }
            renderProgramsList();
        }

        // ===================== RENDER PROGRAMS LIST =====================
        function renderProgramsList() {
            const filtered = getFilteredPrograms();
            document.getElementById('programsCountBadge').textContent = `${filtered.length} من أصل ${programsData.length} برنامج`;

            if (currentView === 'cards') {
                renderCards(filtered);
            } else {
                renderTable(filtered);
            }
        }

        function getDomainBadge(domain) {
            if (domain.includes('الإدارة المدرسية')) {
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200/60">الإدارة المدرسية</span>';
            } else if (domain.includes('نواتج التعلم')) {
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">نواتج التعلم</span>';
            } else if (domain.includes('التعليم والتعلم')) {
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60">التعليم والتعلم</span>';
            } else {
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200/60">' + domain + '</span>';
            }
        }

        function renderCards(list) {
            const container = document.getElementById('cardsViewContainer');
            if (list.length === 0) {
                container.innerHTML = `
                    <div class="col-span-full py-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
                        <svg class="w-12 h-12 mx-auto mb-2 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <p class="font-bold">لا توجد برامج مطابقة لخيارات البحث أو التصفية الحالية</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = list.map(p => {
                const prog = parseInt(p.progress) || 0;
                const link = p.barcode_link || '#';
                const hasValidLink = link && link !== '#' && link.startsWith('http');

                return `
                    <div class="card-soft p-4 rounded-2xl flex flex-col justify-between space-y-3.5 relative overflow-hidden group">
                        
                        <!-- Top Metadata -->
                        <div class="space-y-1.5">
                            <div class="flex items-center justify-between gap-2">
                                <span class="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">${p.id}</span>
                                ${getDomainBadge(p.domain)}
                            </div>
                            <h3 class="text-base font-bold text-slate-800 group-hover:text-emerald-700 transition leading-snug">${p.name}</h3>
                            <p class="text-xs text-slate-600 line-clamp-2 leading-relaxed">${p.detailed_goal || p.program_goal || 'برنامج تشغيلي معتمد'}</p>
                        </div>

                        <!-- Responsible & Target Info -->
                        <div class="bg-slate-50/90 p-2.5 rounded-xl border border-slate-100 text-xs space-y-1">
                            <div class="flex items-center justify-between text-slate-600">
                                <span class="text-slate-400 font-medium">المنفذ:</span>
                                <span class="font-bold text-slate-800">${p.executor}</span>
                            </div>
                            <div class="flex items-center justify-between text-slate-600">
                                <span class="text-slate-400 font-medium">المستهدف:</span>
                                <span class="font-medium text-emerald-700">${p.target_kpi || '95%'}</span>
                            </div>
                        </div>

                        <!-- Progress Bar & Slider -->
                        <div class="space-y-1.5 pt-1">
                            <div class="flex items-center justify-between text-xs">
                                <span class="font-bold text-slate-700">نسبة الإنجاز:</span>
                                <span class="font-black text-xs ${prog === 100 ? 'text-emerald-600' : 'text-blue-700'}" id="progValDisplay_${p.id}">${prog}%</span>
                            </div>
                            <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                                <div id="progBar_${p.id}" class="h-full transition-all duration-300 rounded-full ${
                                    prog === 100 ? 'bg-emerald-500' : (prog > 0 ? 'bg-blue-500' : 'bg-slate-300')
                                }" style="width: ${prog}%"></div>
                            </div>
                            <!-- Interactive Slider -->
                            <input type="range" min="0" max="100" step="5" value="${prog}" 
                                   onchange="updateProgramProgress('${p.id}', this.value)"
                                   oninput="document.getElementById('progValDisplay_${p.id}').textContent = this.value + '%'; document.getElementById('progBar_${p.id}').style.width = this.value + '%';"
                                   class="w-full accent-emerald-600 cursor-pointer h-1 bg-transparent no-print">
                        </div>

                        <!-- Action Buttons: WEB LINK & QR CODE -->
                        <div class="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                            <!-- Web Navigation Button (Requested by Client) -->
                            <a href="${link}" target="_blank" rel="noopener noreferrer" 
                               class="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition ${
                                   hasValidLink ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200/80 shadow-xs' : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                               }" title="انتقال مباشر لرابط الشواهد على الويب">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                <span>فتح الشواهد على الويب</span>
                            </a>

                            <!-- Barcode / QR Button -->
                            <button onclick="openQrModal('${p.id}')" 
                                    class="px-3 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-900 text-white rounded-xl flex items-center gap-1 shadow-xs transition"
                                    title="عرض وإضافة وتوليد باركود الشواهد">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
                                <span>الباركود</span>
                            </button>
                        </div>

                    </div>
                `;
            }).join('');
        }

        function renderTable(list) {
            const tbody = document.getElementById('tableBodyContainer');
            tbody.innerHTML = list.map(p => {
                const prog = parseInt(p.progress) || 0;
                const link = p.barcode_link || '#';
                return `
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="py-2.5 px-3 font-mono font-bold text-slate-500">${p.id}</td>
                        <td class="py-2.5 px-4 font-bold text-slate-800">${p.name}</td>
                        <td class="py-2.5 px-3">${getDomainBadge(p.domain)}</td>
                        <td class="py-2.5 px-3 text-slate-700">${p.executor}</td>
                        <td class="py-2.5 px-3 text-emerald-700 font-medium">${p.target_kpi || '-'}</td>
                        <td class="py-2.5 px-3">
                            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
                                prog === 100 ? 'bg-emerald-100 text-emerald-800' : (prog > 0 ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800')
                            }">${prog === 100 ? 'مكتمل' : (prog > 0 ? 'جارٍ التنفيذ' : 'لم يبدأ')}</span>
                        </td>
                        <td class="py-2.5 px-3 text-center">
                            <div class="flex items-center justify-center gap-1.5">
                                <span class="font-bold">${prog}%</span>
                                <div class="w-12 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                                    <div class="bg-emerald-600 h-full" style="width: ${prog}%"></div>
                                </div>
                            </div>
                        </td>
                        <td class="py-2.5 px-3 text-center">
                            <a href="${link}" target="_blank" class="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-900 font-bold underline text-xs">
                                <span>انتقال للرابط</span>
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                            </a>
                        </td>
                        <td class="py-2.5 px-3 text-center">
                            <button onclick="openQrModal('${p.id}')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-bold">
                                عرض QR
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        // ===================== PROGRESS UPDATE =====================
        function updateProgramProgress(id, newProgress) {
            const prog = programsData.find(p => p.id === id);
            if (prog) {
                prog.progress = parseInt(newProgress);
                if (prog.progress === 100) {
                    prog.status = 'مكتمل';
                } else if (prog.progress > 0) {
                    prog.status = 'جارٍ التنفيذ';
                } else {
                    prog.status = 'لم يبدأ';
                }
                saveData();
                renderKPIs();
                renderExecutorsComparison();
                showToast(`تم تحديث نسبة إنجاز ${prog.name} إلى ${newProgress}%`);
            }
        }

        // ===================== QR CODE & LINK MODAL =====================
        function openQrModal(id) {
            activeModalProgId = id;
            const prog = programsData.find(p => p.id === id);
            if (!prog) return;

            document.getElementById('modalProgramName').textContent = prog.name;
            document.getElementById('modalProgramId').textContent = `${prog.id} • ${prog.executor}`;
            document.getElementById('modalLinkInput').value = prog.barcode_link || '';

            // Generate QR Code
            generateQrCode(prog.barcode_link || `https://mawahib-taiba.edu.sa/evidence/${prog.id}`);

            document.getElementById('qrModal').classList.remove('hidden');
        }

        function closeQrModal() {
            document.getElementById('qrModal').classList.add('hidden');
            activeModalProgId = null;
        }

        function generateQrCode(url) {
            const container = document.getElementById('qrcodeCanvas');
            container.innerHTML = '';
            
            try {
                qrCodeInstance = new QRCode(container, {
                    text: url,
                    width: 160,
                    height: 160,
                    colorDark: '#0f172a',
                    colorLight: '#ffffff',
                    correctLevel: QRCode.CorrectLevel.H
                });
            } catch(e) {
                container.innerHTML = '<span class="text-xs text-red-500 font-bold">فشل توليد الباركود</span>';
            }
        }

        function saveModalLink() {
            if (!activeModalProgId) return;
            const newLink = document.getElementById('modalLinkInput').value.trim();
            const prog = programsData.find(p => p.id === activeModalProgId);
            if (prog) {
                prog.barcode_link = newLink;
                saveData();
                generateQrCode(newLink || `https://mawahib-taiba.edu.sa/evidence/${prog.id}`);
                renderProgramsList();
                showToast('تم حفظ وتحديث رابط الشواهد والباركود بنجاح');
            }
        }

        function openModalWebLink() {
            const url = document.getElementById('modalLinkInput').value.trim();
            if (url) {
                window.open(url, '_blank');
            } else {
                alert('يرجى إدخال رابط صالح أولاً');
            }
        }

        function downloadQrImage() {
            const container = document.getElementById('qrcodeCanvas');
            const img = container.querySelector('img');
            const canvas = container.querySelector('canvas');
            
            let dataUrl = '';
            if (img && img.src) {
                dataUrl = img.src;
            } else if (canvas) {
                dataUrl = canvas.toDataURL('image/png');
            }

            if (dataUrl) {
                const a = document.createElement('a');
                a.href = dataUrl;
                a.download = `QR_${activeModalProgId}_شواهد.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                showToast('تم تنزيل صورة الباركود بنجاح');
            } else {
                alert('تعذر استخراج صورة الباركود');
            }
        }

        // ===================== ADD NEW PROGRAM MODAL =====================
        function openAddProgramModal() {
            document.getElementById('addProgramModal').classList.remove('hidden');
        }

        function closeAddProgramModal() {
            document.getElementById('addProgramModal').classList.add('hidden');
            document.getElementById('addProgramForm').reset();
        }

        function submitNewProgram(e) {
            e.preventDefault();
            const newId = 'PRG-' + String(programsData.length + 1).padStart(3, '0');
            const name = document.getElementById('newProgName').value.trim();
            const domain = document.getElementById('newProgDomain').value;
            const executor = document.getElementById('newProgExecutor').value.trim();
            const target = document.getElementById('newProgTarget').value.trim() || '95%';
            const supporter = document.getElementById('newProgSupporter').value.trim() || '';
            const link = document.getElementById('newProgLink').value.trim() || `https://mawahib-taiba.edu.sa/evidence/${newId}`;

            const newProgram = {
                id: newId,
                name: name,
                domain: domain,
                executor: executor,
                supporter: supporter,
                target_kpi: target,
                start_date: '1448/03/17',
                end_date: '1448/12/30',
                status: 'لم يبدأ',
                progress: 0,
                barcode_link: link,
                detailed_goal: 'مبادرة مضافة حديثاً إلى الخطة التشغيلية'
            };

            programsData.push(newProgram);
            saveData();
            closeAddProgramModal();
            renderDashboard();
            showToast(`تمت إضافة برنامج «${name}» بنجاح!`);
        }

        // ===================== EXPORT TO CSV / EXCEL =====================
        function exportDataToCSV() {
            let csvContent = "\\uFEFF"; // BOM for Arabic support in Excel
            csvContent += "معرّف البرنامج,اسم البرنامج,المجال,مسؤول التنفيذ,الجهة المساندة,المستهدف,حالة التنفيذ,نسبة الإنجاز,رابط الشواهد\\n";

            programsData.forEach(p => {
                const row = [
                    `"${p.id}"`,
                    `"${(p.name || '').replace(/"/g, '""')}"`,
                    `"${(p.domain || '').replace(/"/g, '""')}"`,
                    `"${(p.executor || '').replace(/"/g, '""')}"`,
                    `"${(p.supporter || '').replace(/"/g, '""')}"`,
                    `"${(p.target_kpi || '').replace(/"/g, '""')}"`,
                    `"${p.status || 'لم يبدأ'}"`,
                    `"${p.progress || 0}%"`,
                    `"${p.barcode_link || ''}"`
                ];
                csvContent += row.join(',') + '\\n';
            });

            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'متابعة_الخطة_التشغيلية_ابتدائية_مواهب_طيبة.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showToast('تم تصدير ملف الإكسل (CSV) بنجاح');
        }

        // ===================== TOAST SYSTEM =====================
        function showToast(msg) {
            const toast = document.getElementById('toastBox');
            document.getElementById('toastMsg').textContent = msg;
            toast.classList.remove('translate-y-20', 'opacity-0');
            toast.classList.add('translate-y-0', 'opacity-100');
            setTimeout(() => {
                toast.classList.add('translate-y-20', 'opacity-0');
                toast.classList.remove('translate-y-0', 'opacity-100');
            }, 3000);
        }
    </script>
</body>
</html>'''

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html_template)

print('Successfully generated index.html')
