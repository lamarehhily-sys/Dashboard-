import sys, json, base64

sys.stdout.reconfigure(encoding='utf-8')

# Read logo base64
with open('files/assets/page3_Image31.png', 'rb') as f:
    logo_b64 = base64.b64encode(f.read()).decode('utf-8')
logo_data_uri = "data:image/png;base64," + logo_b64

# Read programs data
with open('files/programs_data.json', 'r', encoding='utf-8') as f:
    programs_json_str = f.read()

template = '''<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم الخطة التشغيلية | ابتدائية مواهب طيبة (طفولة مبكرة)</title>
    
    <!-- Local Styles & Fonts -->
    <link rel="stylesheet" href="files/libs/tailwind.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Local Scripts -->
    <script src="files/libs/chart.umd.min.js"></script>
    <script src="files/libs/qrcode.min.js"></script>
    <script src="files/libs/xlsx.full.min.js"></script>
    
    <style>
        :root {
            --brand-green-dark: #064E3B;
            --brand-green: #0D6E54;
            --brand-teal: #0284A8;
            --brand-gold: #C5A059;
            --brand-gold-light: #F7EBD2;
            --body-bg: #F4F7F6;
        }
        body {
            font-family: 'Tajawal', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--body-bg);
            color: #1e293b;
            scroll-behavior: smooth;
        }
        .header-gradient {
            background: linear-gradient(135deg, #053D2E 0%, #064E3B 45%, #0B5746 75%, #0F4C81 100%);
            border-bottom: 4px solid #C5A059;
        }
        .gold-pill {
            background: rgba(197, 160, 89, 0.18);
            color: #FDF4E3;
            border: 1px solid rgba(197, 160, 89, 0.45);
        }
        .card-executive {
            background: #ffffff;
            border: 1px solid #E2E8F0;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.04), 0 2px 4px -2px rgba(0, 0, 0, 0.02);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card-executive:hover {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.06), 0 4px 6px -4px rgba(0, 0, 0, 0.03);
            border-color: #CBD5E1;
        }
        .slicer-select {
            height: 44px;
            border-radius: 0.75rem;
            border: 1.5px solid #CBD5E1;
            background-color: #ffffff;
            font-size: 0.825rem;
            font-weight: 600;
            color: #1E293B;
            padding-left: 0.75rem;
            padding-right: 0.75rem;
            transition: border-color 0.15s, box-shadow 0.15s;
        }
        .slicer-select:focus {
            outline: none;
            border-color: #0D6E54;
            box-shadow: 0 0 0 3px rgba(13, 110, 84, 0.18);
        }
        .program-card {
            background: #ffffff;
            border: 1px solid #E2E8F0;
            border-radius: 1.25rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.03);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .program-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 20px -3px rgba(0, 0, 0, 0.08);
        }
        .lead-card-active {
            border-color: #0D6E54 !important;
            background-color: #ECFDF5 !important;
            box-shadow: 0 0 0 2px #0D6E54 !important;
        }
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
            .card-executive, .program-card { box-shadow: none !important; border: 1px solid #CBD5E1 !important; break-inside: avoid; }
        }
    </style>
</head>
<body class="min-h-screen flex flex-col justify-between" id="appBody">

    <!-- ===================== 1. DISTINCT HEADER (COLORS FROM PDF) ===================== -->
    <header class="header-gradient text-white shadow-xl sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
            <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                
                <!-- School & Ministry Brand -->
                <div class="flex items-center gap-3.5 w-full md:w-auto">
                    <!-- Ministry of Education Logo in White Box -->
                    <div class="h-13 w-20 bg-white p-1.5 rounded-xl shadow-md flex items-center justify-center shrink-0 border border-white/20">
                        <img src="###LOGO_DATA_URI###" alt="شعار وزارة التعليم" class="h-full object-contain">
                    </div>

                    <!-- School Title & Subtitle with Gold Accents -->
                    <div>
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="gold-pill px-2.5 py-0.5 text-[11px] font-bold rounded-full">الرقم الوزاري: S-41529</span>
                            <span class="px-2.5 py-0.5 text-[11px] font-bold bg-white/15 text-emerald-100 rounded-full border border-white/20">1448هـ</span>
                            <span class="text-xs text-emerald-200 hidden sm:inline">• المدينة المنورة</span>
                        </div>
                        <h1 class="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5 flex items-center gap-1.5">
                            <span>ابتدائية مواهب طيبة</span>
                            <span class="text-[#FCE7B8] font-bold text-base sm:text-lg">(طفولة مبكرة)</span>
                        </h1>
                        <p class="text-xs text-emerald-100/90 font-medium">لوحة متابعة الخطة التشغيلية السنوية • الإدارة العامة للتعليم بمنطقة المدينة المنورة</p>
                    </div>
                </div>

                <!-- Header Actions Bar -->
                <div class="flex items-center gap-2 w-full md:w-auto justify-end no-print flex-wrap">
                    <!-- Read From Excel Button -->
                    <label class="cursor-pointer flex items-center gap-1.5 px-3.5 py-2 text-xs font-black bg-[#C5A059] hover:bg-[#B38D45] text-slate-900 rounded-xl shadow-md transition" title="قراءة وتحديث القيم من ملف الإكسل مباشرة">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                        <span>تحديث من ملف Excel</span>
                        <input type="file" id="excelFileInput" accept=".xlsx, .xls" class="hidden" onchange="handleExcelFileUpload(event)">
                    </label>

                    <!-- Print Button -->
                    <button onclick="window.print()" class="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-white/15 hover:bg-white/25 rounded-xl border border-white/20 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                        <span>طباعة</span>
                    </button>

                    <!-- Export CSV Button -->
                    <button onclick="exportDataToCSV()" class="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-emerald-600/80 hover:bg-emerald-600 rounded-xl border border-emerald-500/40 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        <span>تصدير</span>
                    </button>

                    <!-- Reset Button -->
                    <button onclick="resetData()" title="استعادة القيم الأصلية من ملف الإكسل" class="p-2 text-white/70 hover:text-white rounded-xl hover:bg-white/10 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                    </button>
                </div>

            </div>
        </div>
    </header>

    <!-- ===================== MAIN CONTENT WRAPPER ===================== -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 w-full flex-grow">

        <!-- ===================== 2. EXECUTIVE SLICERS (ALIGNED & SYMMETRIC) ===================== -->
        <section class="card-executive p-4 bg-white border-t-4 border-t-[#0D6E54] space-y-3">
            <div class="flex items-center justify-between flex-wrap gap-2">
                <div class="flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse"></span>
                    <h2 class="text-xs font-black text-slate-800 uppercase tracking-wider">محددات التصفية والمتابعة (Slicers)</h2>
                </div>
                <div class="flex items-center gap-3">
                    <span class="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200" id="syncStatusBadge">
                        مترابط مع ملف الإكسل 🟢
                    </span>
                    <button id="resetFiltersBtn" onclick="resetAllFilters()" class="text-xs text-red-600 hover:text-red-800 font-bold hidden">
                        إعادة ضبط الفلاتر ✕
                    </button>
                </div>
            </div>

            <!-- Unified Slicer Grid (4 Columns) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                
                <!-- Slicer 1: Domain -->
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">المجال التعليمي:</label>
                    <select id="slicerDomain" onchange="applySlicers()" class="slicer-select w-full">
                        <option value="all">جميع المجالات (13 برنامج)</option>
                        <option value="الإدارة المدرسية">الإدارة المدرسية (8 برامج)</option>
                        <option value="نواتج التعلم">نواتج التعلم (4 برامج)</option>
                        <option value="التعليم والتعلم">التعليم والتعلم (برنامجان)</option>
                        <option value="البيئة المدرسية">البيئة المدرسية (برنامجان)</option>
                    </select>
                </div>

                <!-- Slicer 2: Status -->
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">حالة التنفيذ:</label>
                    <select id="slicerStatus" onchange="applySlicers()" class="slicer-select w-full">
                        <option value="all">جميع الحالات</option>
                        <option value="مكتمل">مكتمل (100%)</option>
                        <option value="جارٍ التنفيذ">جارٍ التنفيذ</option>
                        <option value="لم يبدأ">لم يبدأ</option>
                    </select>
                </div>

                <!-- Slicer 3: Responsible Lead -->
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">مسؤول التنفيذ:</label>
                    <select id="slicerExecutor" onchange="applySlicers()" class="slicer-select w-full">
                        <option value="all">جميع مسؤولي التنفيذ</option>
                        <option value="الموجهة الطلابية">الموجهة الطلابية (5 برامج)</option>
                        <option value="معلمات المواد المستهدفة">معلمات المواد المستهدفة (برنامجان)</option>
                        <option value="وكيلة المدرسة للشؤون الطلابية">وكيلة المدرسة للشؤون الطلابية</option>
                        <option value="منسقة الموهوبات / هيلة الجهني">منسقة الموهوبات / هيلة الجهني</option>
                        <option value="مديرة المدرسة">مديرة المدرسة</option>
                        <option value="سهيلة / عواطف">سهيلة / عواطف (الشؤون التعليمية)</option>
                        <option value="الموجهة الصحية">الموجهة الصحية</option>
                        <option value="الهيئة الإدارية">الهيئة الإدارية</option>
                    </select>
                </div>

                <!-- Slicer 4: Instant Search -->
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">البحث السريع:</label>
                    <div class="relative">
                        <input type="text" id="slicerSearch" oninput="applySlicers()" placeholder="بحث باسم البرنامج، المنفذ..." 
                               class="slicer-select w-full pr-8 pl-8">
                        <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-slate-400">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        </div>
                        <button onclick="document.getElementById('slicerSearch').value=''; applySlicers();" class="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400 hover:text-slate-600">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        </button>
                    </div>
                </div>

            </div>
        </section>

        <!-- ===================== 3. EXECUTIVE KPI CARDS (RICH COLORS FROM PDF) ===================== -->
        <section class="grid grid-cols-2 lg:grid-cols-5 gap-4">
            
            <!-- Card 1: Overall Progress -->
            <div class="col-span-2 sm:col-span-1 card-executive p-4.5 rounded-2xl flex items-center justify-between bg-gradient-to-br from-[#064E3B] to-[#0D6E54] text-white shadow-md">
                <div class="space-y-0.5">
                    <span class="text-xs font-bold text-[#FCE7B8] uppercase">معدل الإنجاز العام</span>
                    <h3 class="text-3xl font-black text-white"><span id="kpiOverallPercent">0</span><span class="text-lg text-emerald-200 mr-0.5">%</span></h3>
                    <p class="text-[10px] text-emerald-100">متوسط تقدم الخطة</p>
                </div>
                <div class="relative w-15 h-15 shrink-0">
                    <svg class="w-15 h-15 -rotate-90" viewBox="0 0 36 36">
                        <path class="text-white/20" stroke-width="3.5" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                        <path id="gaugeProgressPath" class="text-[#FCE7B8]" stroke-dasharray="0, 100" stroke-width="3.5" stroke-linecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div class="absolute inset-0 flex items-center justify-center font-black text-xs text-white">
                        <span id="gaugeText">0%</span>
                    </div>
                </div>
            </div>

            <!-- Card 2: Total Programs -->
            <div class="card-executive p-4 rounded-2xl flex flex-col justify-between border-t-4 border-t-blue-600 bg-white">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-slate-700">إجمالي البرامج</span>
                    <span class="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md text-[10px] font-bold">1448هـ</span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-slate-900" id="kpiTotalPrograms">13</div>
                    <span class="text-[11px] text-slate-500 font-medium">برنامج ومبادرة معتمدة</span>
                </div>
            </div>

            <!-- Card 3: Completed Programs -->
            <div class="card-executive p-4 rounded-2xl flex flex-col justify-between border-t-4 border-t-emerald-600 bg-white">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-emerald-800">برامج مكتملة</span>
                    <span class="p-1 bg-emerald-100 text-emerald-700 rounded-full text-xs">✓</span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-emerald-600" id="kpiCompletedPrograms">0</div>
                    <span class="text-[11px] text-slate-500 font-medium">منجزة بنسبة 100%</span>
                </div>
            </div>

            <!-- Card 4: In Progress -->
            <div class="card-executive p-4 rounded-2xl flex flex-col justify-between border-t-4 border-t-cyan-600 bg-white">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-cyan-800">قيد التنفيذ</span>
                    <span class="w-2.5 h-2.5 rounded-full bg-cyan-500 animate-pulse"></span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-cyan-700" id="kpiInProgressPrograms">0</div>
                    <span class="text-[11px] text-slate-500 font-medium">متابعة مستمرة</span>
                </div>
            </div>

            <!-- Card 5: Not Started -->
            <div class="card-executive p-4 rounded-2xl flex flex-col justify-between border-t-4 border-t-amber-500 bg-white">
                <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-amber-800">لم يبدأ / معلق</span>
                    <span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-amber-600" id="kpiPendingPrograms">13</div>
                    <span class="text-[11px] text-slate-500 font-medium">حسب الجدولة الزمنية</span>
                </div>
            </div>

        </section>

        <!-- ===================== 4. VISUAL FOR المسؤولين ===================== -->
        <section class="card-executive p-5 bg-white border-t-4 border-t-[#C5A059] space-y-4">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2.5">
                    <div class="p-2 bg-[#F7EBD2] text-[#8C6D23] rounded-xl font-bold text-sm">
                        👥
                    </div>
                    <div>
                        <h2 class="text-base font-black text-slate-900">فريق العمل ومسؤولو التنفيذ (المسؤولين)</h2>
                        <p class="text-xs text-slate-500">انقر على بطاقة أي مسؤول لتصفية وعرض برامجه في الخطة بالأسفل فوراً</p>
                    </div>
                </div>

                <div id="activeLeadFilterTag" class="hidden items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-200 text-xs font-bold">
                    <span>محدد: <span id="activeLeadName"></span></span>
                    <button onclick="filterByLead('all')" class="text-emerald-700 hover:text-emerald-950 font-black">✕</button>
                </div>
            </div>

            <!-- Visual Lead Cards Grid -->
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3" id="leadsCardsContainer">
                <!-- Populated via JS -->
            </div>

            <!-- Comparison Bar Chart Container -->
            <div class="pt-3 border-t border-slate-100">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-slate-700">مقارنة أداء وعبء العمل لمسؤولي البرامج (عدد البرامج vs نسبة الإنجاز):</span>
                </div>
                <div class="h-52 w-full bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <canvas id="executorsChart"></canvas>
                </div>
            </div>
        </section>

        <!-- ===================== 5. OPERATIONAL PLAN CARDS (FRONT & CENTER) ===================== -->
        <section class="space-y-4">
            
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2.5">
                    <div class="w-3 h-6 bg-[#0D6E54] rounded-full"></div>
                    <h2 class="text-lg sm:text-xl font-black text-slate-900">بطاقات برامج ومبادرات الخطة التشغيلية</h2>
                    <span class="text-xs font-bold px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full" id="programsCountBadge">13 برنامج</span>
                </div>

                <div class="flex items-center gap-2 no-print">
                    <!-- Cards / Table Toggle -->
                    <div class="flex items-center bg-slate-200/80 p-1 rounded-xl text-xs font-bold">
                        <button id="viewCardsBtn" onclick="switchView('cards')" class="px-3.5 py-1.5 rounded-lg bg-white text-emerald-900 shadow-sm transition">
                            عرض البطاقات
                        </button>
                        <button id="viewTableBtn" onclick="switchView('table')" class="px-3.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition">
                            عرض الجدول
                        </button>
                    </div>

                    <button onclick="openAddProgramModal()" class="px-3.5 py-2 text-xs font-bold bg-[#0D6E54] hover:bg-[#084E3B] text-white rounded-xl shadow-sm flex items-center gap-1.5 transition">
                        <span>+ إضافة برنامج</span>
                    </button>
                </div>
            </div>

            <!-- CARDS VIEW (PROMINENT & COLORFUL) -->
            <div id="cardsViewContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4.5">
                <!-- Dynamically generated cards -->
            </div>

            <!-- TABLE VIEW -->
            <div id="tableViewContainer" class="card-executive rounded-2xl overflow-hidden hidden bg-white">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 text-right text-xs">
                        <thead class="bg-slate-100 text-slate-800 font-black">
                            <tr>
                                <th class="py-3.5 px-3">المعرّف</th>
                                <th class="py-3.5 px-4">البرنامج والمبادرة</th>
                                <th class="py-3.5 px-3">المجال</th>
                                <th class="py-3.5 px-3">مسؤول التنفيذ</th>
                                <th class="py-3.5 px-3">المستهدف</th>
                                <th class="py-3.5 px-3">الحالة</th>
                                <th class="py-3.5 px-3 text-center">نسبة الإنجاز</th>
                                <th class="py-3.5 px-3 text-center">رابط الشواهد (Google Drive)</th>
                                <th class="py-3.5 px-3 text-center">الباركود (QR)</th>
                            </tr>
                        </thead>
                        <tbody id="tableBodyContainer" class="divide-y divide-slate-100 bg-white">
                            <!-- Dynamically generated table rows -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

    </main>

    <!-- ===================== FOOTER ===================== -->
    <footer class="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 mt-8">
        <div class="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2 font-medium">
            <p>الخطة التشغيلية السنوية • ابتدائية مواهب طيبة (طفولة مبكرة) • 1448هـ</p>
            <p class="text-slate-400">لوحة التحكم والمتابعة المترابطة | مستندة لملف الخطة التشغيلية</p>
        </div>
    </footer>

    <!-- ===================== MODAL: QR CODE & EVIDENCE ===================== -->
    <div id="qrModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2">
                    <div class="p-2 bg-emerald-50 text-emerald-800 rounded-xl font-bold">
                        📱
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-slate-900" id="modalProgramName">باركود شواهد البرنامج</h3>
                        <span class="text-xs text-slate-500 font-bold" id="modalProgramId">PRG-000</span>
                    </div>
                </div>
                <button onclick="closeQrModal()" class="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition">
                    ✕
                </button>
            </div>

            <!-- QR Container -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col items-center justify-center space-y-2">
                <div id="qrcodeCanvas" class="bg-white p-3 rounded-xl shadow-sm border border-slate-200"></div>
                <p class="text-[11px] text-slate-600 font-bold text-center">امسح الباركود بكاميرا الجوال للانتقال لملف الشواهد في Google Drive</p>
            </div>

            <!-- Web Link Input & Update -->
            <div class="space-y-1.5">
                <label class="block text-xs font-bold text-slate-700">رابط الشواهد في Google Drive:</label>
                <div class="flex items-center gap-2">
                    <input type="url" id="modalLinkInput" class="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50 font-mono" placeholder="https://drive.google.com/...">
                    <button onclick="saveModalLink()" class="px-3.5 py-2 text-xs font-bold bg-[#0D6E54] hover:bg-[#064E3B] text-white rounded-xl transition">حفظ</button>
                </div>
            </div>

            <!-- Modal Action Buttons -->
            <div class="grid grid-cols-2 gap-2 pt-1">
                <button onclick="openModalWebLink()" class="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl border border-blue-200 transition">
                    <span>فتح في Google Drive</span>
                </button>
                <button onclick="downloadQrImage()" class="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-slate-900 hover:bg-black text-white rounded-xl transition">
                    <span>تنزيل الباركود PNG</span>
                </button>
            </div>
        </div>
    </div>

    <!-- ===================== MODAL: ADD NEW PROGRAM ===================== -->
    <div id="addProgramModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
        <div class="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 class="text-sm font-black text-slate-800">إضافة برنامج أو مبادرة تشغيلية جديدة</h3>
                <button onclick="closeAddProgramModal()" class="text-slate-400 hover:text-slate-600 p-1 rounded-lg">✕</button>
            </div>

            <form id="addProgramForm" onsubmit="submitNewProgram(event)" class="space-y-3 text-xs">
                <div>
                    <label class="block font-bold text-slate-700 mb-1">اسم البرنامج / المبادرة:</label>
                    <input type="text" id="newProgName" required class="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white" placeholder="مثال: تعزيز المهارات الرقمية">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">المجال:</label>
                        <select id="newProgDomain" class="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50">
                            <option value="الإدارة المدرسية">الإدارة المدرسية</option>
                            <option value="نواتج التعلم">نواتج التعلم</option>
                            <option value="التعليم والتعلم">التعليم والتعلم</option>
                            <option value="البيئة المدرسية">البيئة المدرسية</option>
                        </select>
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">مسؤول التنفيذ:</label>
                        <input type="text" id="newProgExecutor" required class="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50" placeholder="مثال: الموجهة الطلابية">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">المستهدف:</label>
                        <input type="text" id="newProgTarget" class="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50" placeholder="مثال: 95%">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">الجهة المساندة:</label>
                        <input type="text" id="newProgSupporter" class="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50" placeholder="مثال: رائدة النشاط">
                    </div>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">رابط الشواهد في Google Drive:</label>
                    <input type="url" id="newProgLink" class="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50 font-mono" placeholder="https://drive.google.com/...">
                </div>

                <div class="pt-2 flex justify-end gap-2">
                    <button type="button" onclick="closeAddProgramModal()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition">إلغاء</button>
                    <button type="submit" class="px-5 py-2 bg-[#0D6E54] hover:bg-[#064E3B] text-white rounded-xl font-bold transition">إضافة البرنامج</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===================== TOAST NOTIFICATION ===================== -->
    <div id="toastBox" class="fixed bottom-5 left-5 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 transform translate-y-20 opacity-0 transition-all duration-300 pointer-events-none">
        <span id="toastMsg">تم الحفظ بنجاح</span>
    </div>

    <!-- ===================== JAVASCRIPT LOGIC ===================== -->
    <script>
        const INITIAL_PROGRAMS = ###PROGRAMS_DATA_JSON###;

        let programsData = [];
        let activeDomain = 'all';
        let activeStatus = 'all';
        let activeExecutor = 'all';
        let currentView = 'cards';
        let activeModalProgId = null;
        let qrCodeInstance = null;
        let comparisonChart = null;

        const LEADS_META = [
            { name: 'عيدة الرشيدي', role: 'مديرة المدرسة / رئيسة الفريق', icon: '👑', color: 'emerald' },
            { name: 'أسماء العارضي', role: 'وكيلة شؤون الطالبات / نائبة', icon: '📋', color: 'blue' },
            { name: 'سامية الحازمي – مارية الجهني', role: 'الموجهة الطلابية', icon: '💡', color: 'indigo' },
            { name: 'هيلة الجهني', role: 'منسقة الموهوبات', icon: '⭐', color: 'amber' },
            { name: 'معلمات المواد المستهدفة', role: 'لجنة التحصيل الدراسي', icon: '📚', color: 'teal' },
            { name: 'الموجهة الصحية', role: 'الصحة المدرسية', icon: '🩺', color: 'rose' }
        ];

        document.addEventListener('DOMContentLoaded', function() {
            loadProgramsData();
            tryAutoReadExcel();
            renderDashboard();
            setupDragAndDrop();
        });

        function loadProgramsData() {
            const saved = localStorage.getItem('mawahib_operational_plan_v3');
            if (saved) {
                try {
                    programsData = JSON.parse(saved);
                } catch(e) {
                    programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
                }
            } else {
                programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
            }
        }

        function saveData() {
            localStorage.setItem('mawahib_operational_plan_v3', JSON.stringify(programsData));
        }

        function resetData() {
            if (confirm('هل ترغب في إعادة ضبط البيانات إلى القيم المعتمدة من ملف الإكسل؟')) {
                localStorage.removeItem('mawahib_operational_plan_v3');
                programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
                renderDashboard();
                showToast('تمت استعادة البيانات الأصلية بنجاح');
            }
        }

        function tryAutoReadExcel() {
            fetch('files/موهبة طيبة- طفولة مبكرة.xlsx')
                .then(function(res) {
                    if (res.ok) return res.arrayBuffer();
                    throw new Error('Local fetch restricted');
                })
                .then(function(data) {
                    parseExcelArrayBuffer(data, false);
                    document.getElementById('syncStatusBadge').textContent = 'قراءة مباشرة من ملف الإكسل 🟢';
                })
                .catch(function(err) {
                    document.getElementById('syncStatusBadge').textContent = 'مترابط مع ملف الإكسل 🟢';
                });
        }

        function handleExcelFileUpload(event) {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(e) {
                const data = new Uint8Array(e.target.result);
                parseExcelArrayBuffer(data, true);
            };
            reader.readAsArrayBuffer(file);
        }

        function setupDragAndDrop() {
            const body = document.getElementById('appBody');
            ['dragenter', 'dragover'].forEach(function(evt) {
                body.addEventListener(evt, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                }, false);
            });
            ['dragleave', 'drop'].forEach(function(evt) {
                body.addEventListener(evt, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                }, false);
            });
            body.addEventListener('drop', function(e) {
                const dt = e.dataTransfer;
                if (dt.files && dt.files.length > 0 && dt.files[0].name.endsWith('.xlsx')) {
                    const reader = new FileReader();
                    reader.onload = function(evt) {
                        parseExcelArrayBuffer(new Uint8Array(evt.target.result), true);
                    };
                    reader.readAsArrayBuffer(dt.files[0]);
                }
            });
        }

        function parseExcelArrayBuffer(data, notify) {
            try {
                const workbook = XLSX.read(data, { type: 'array' });
                const targetSheetName = workbook.SheetNames.includes('متابعة التنفيذ') ? 'متابعة التنفيذ' : workbook.SheetNames[0];
                const ws = workbook.Sheets[targetSheetName];
                const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

                let updatedCount = 0;
                rows.forEach(function(r) {
                    if (r && r.length > 1) {
                        const progName = String(r[0] || '').trim();
                        const match = programsData.find(function(p) {
                            return p.name.includes(progName) || progName.includes(p.name);
                        });
                        if (match) {
                            if (r[8] && String(r[8]).trim() !== '') match.status = String(r[8]).trim();
                            if (r[9] !== undefined && r[9] !== '') {
                                let pVal = parseFloat(r[9]);
                                if (pVal <= 1.0 && pVal > 0) pVal = Math.round(pVal * 100);
                                if (!isNaN(pVal)) match.progress = parseInt(pVal);
                            }
                            if (r[10] && String(r[10]).startsWith('http')) match.barcode_link = String(r[10]).trim();
                            updatedCount++;
                        }
                    }
                });

                saveData();
                renderDashboard();
                if (notify) {
                    showToast('تم تحديث ' + updatedCount + ' برنامج من ملف الإكسل بنجاح!');
                }
            } catch(err) {
                console.error('Error parsing excel:', err);
                if (notify) alert('تعذر قراءة ملف الإكسل، يرجى التأكد من اختيار ملف صحيح.');
            }
        }

        function renderDashboard() {
            renderKPIs();
            renderLeadsVisual();
            renderExecutorsChart();
            renderProgramsList();
        }

        function renderKPIs() {
            const total = programsData.length;
            let sumProgress = 0;
            let completed = 0;
            let inProgress = 0;
            let pending = 0;

            programsData.forEach(function(p) {
                const prog = parseInt(p.progress) || 0;
                sumProgress += prog;
                if (prog === 100 || p.status === 'مكتمل') {
                    completed++;
                } else if (prog > 0 || p.status === 'جارٍ التنفيذ') {
                    inProgress++;
                } else {
                    pending++;
                }
            });

            const avgProgress = total > 0 ? Math.round(sumProgress / total) : 0;

            document.getElementById('kpiTotalPrograms').textContent = total;
            document.getElementById('kpiCompletedPrograms').textContent = completed;
            document.getElementById('kpiInProgressPrograms').textContent = inProgress;
            document.getElementById('kpiPendingPrograms').textContent = pending;
            document.getElementById('kpiOverallPercent').textContent = avgProgress;
            document.getElementById('gaugeText').textContent = avgProgress + '%';

            const path = document.getElementById('gaugeProgressPath');
            if (path) {
                path.setAttribute('stroke-dasharray', avgProgress + ', 100');
            }
        }

        function renderLeadsVisual() {
            const container = document.getElementById('leadsCardsContainer');
            if (!container) return;

            const leadsSummary = LEADS_META.map(function(lead) {
                const matchingProgs = programsData.filter(function(p) {
                    const ex = (p.executor || '').trim();
                    return ex.includes(lead.name) || lead.name.includes(ex) || (lead.name.includes('الموجهة الطلابية') && ex.includes('الموجهة الطلابية'));
                });

                const count = matchingProgs.length;
                let sum = 0;
                matchingProgs.forEach(function(p) { sum += (parseInt(p.progress) || 0); });
                const avg = count > 0 ? Math.round(sum / count) : 0;

                return {
                    name: lead.name,
                    role: lead.role,
                    icon: lead.icon,
                    programsCount: count,
                    avgProgress: avg
                };
            });

            container.innerHTML = leadsSummary.map(function(lead) {
                const isSelected = activeExecutor !== 'all' && (activeExecutor.includes(lead.name) || lead.name.includes(activeExecutor));
                const activeClass = isSelected ? 'lead-card-active' : 'bg-slate-50 hover:bg-white border-slate-200';
                
                return '<div data-lead="' + lead.name + '" onclick="filterByLead(this.dataset.lead)" class="p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-right ' + activeClass + '">' +
                    '<div class="flex items-center justify-between mb-2">' +
                        '<span class="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-sm shadow-sm">' + lead.icon + '</span>' +
                        '<span class="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">' + lead.programsCount + ' برامج</span>' +
                    '</div>' +
                    '<div>' +
                        '<h3 class="text-xs font-bold text-slate-800 line-clamp-1">' + lead.name + '</h3>' +
                        '<p class="text-[10px] text-slate-500 line-clamp-1 mt-0.5">' + lead.role + '</p>' +
                    '</div>' +
                    '<div class="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">' +
                        '<span class="text-slate-400 text-[10px]">الإنجاز:</span>' +
                        '<span class="font-black text-emerald-800">' + lead.avgProgress + '%</span>' +
                    '</div>' +
                    '<div class="w-full bg-slate-200 h-1.5 rounded-full mt-1 overflow-hidden">' +
                        '<div class="bg-[#0D6E54] h-full rounded-full transition-all duration-300" style="width: ' + lead.avgProgress + '%"></div>' +
                    '</div>' +
                '</div>';
            }).join('');
        }

        function filterByLead(leadName) {
            const tag = document.getElementById('activeLeadFilterTag');
            const tagText = document.getElementById('activeLeadName');

            if (leadName === 'all' || activeExecutor === leadName) {
                activeExecutor = 'all';
                document.getElementById('slicerExecutor').value = 'all';
                tag.classList.add('hidden');
            } else {
                activeExecutor = leadName;
                document.getElementById('slicerExecutor').value = leadName;
                tag.classList.remove('hidden');
                tagText.textContent = leadName;
            }

            checkActiveFilters();
            renderLeadsVisual();
            renderProgramsList();
        }

        function renderExecutorsChart() {
            const execMap = {};
            programsData.forEach(function(p) {
                const ex = (p.executor || 'غير محدد').trim();
                if (!execMap[ex]) execMap[ex] = { count: 0, sumProgress: 0 };
                execMap[ex].count += 1;
                execMap[ex].sumProgress += (parseInt(p.progress) || 0);
            });

            const labels = [];
            const counts = [];
            const averages = [];

            for (const ex in execMap) {
                labels.push(ex.length > 20 ? ex.substring(0, 18) + '...' : ex);
                counts.push(execMap[ex].count);
                averages.push(Math.round(execMap[ex].sumProgress / execMap[ex].count));
            }

            const ctx = document.getElementById('executorsChart');
            if (ctx) {
                if (comparisonChart) comparisonChart.destroy();

                comparisonChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'عدد البرامج المسندة',
                                data: counts,
                                backgroundColor: '#0D6E54',
                                borderRadius: 6,
                                yAxisID: 'y'
                            },
                            {
                                label: 'متوسط نسبة الإنجاز (%)',
                                data: averages,
                                backgroundColor: '#C5A059',
                                borderRadius: 6,
                                yAxisID: 'y1'
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: { mode: 'index', intersect: false },
                        plugins: {
                            legend: {
                                position: 'top',
                                labels: { font: { family: 'Tajawal', size: 11 }, boxWidth: 12 }
                            },
                            tooltip: { rtl: true, titleFont: { family: 'Tajawal' }, bodyFont: { family: 'Tajawal' } }
                        },
                        scales: {
                            x: { ticks: { font: { family: 'Tajawal', size: 10 } }, grid: { display: false } },
                            y: {
                                type: 'linear',
                                display: true,
                                position: 'right',
                                title: { display: true, text: 'عدد البرامج', font: { family: 'Tajawal', size: 10 } },
                                min: 0,
                                ticks: { stepSize: 1 }
                            },
                            y1: {
                                type: 'linear',
                                display: true,
                                position: 'left',
                                title: { display: true, text: 'الإنجاز %', font: { family: 'Tajawal', size: 10 } },
                                min: 0,
                                max: 100,
                                grid: { drawOnChartArea: false }
                            }
                        }
                    }
                });
            }
        }

        function applySlicers() {
            activeDomain = document.getElementById('slicerDomain').value;
            activeStatus = document.getElementById('slicerStatus').value;
            activeExecutor = document.getElementById('slicerExecutor').value;
            
            checkActiveFilters();
            renderLeadsVisual();
            renderProgramsList();
        }

        function checkActiveFilters() {
            const resetBtn = document.getElementById('resetFiltersBtn');
            const searchVal = document.getElementById('slicerSearch') ? document.getElementById('slicerSearch').value : '';
            const isFiltered = (activeDomain !== 'all' || activeStatus !== 'all' || activeExecutor !== 'all' || searchVal.trim() !== '');

            if (isFiltered) {
                resetBtn.classList.remove('hidden');
            } else {
                resetBtn.classList.add('hidden');
                document.getElementById('activeLeadFilterTag').classList.add('hidden');
            }
        }

        function resetAllFilters() {
            document.getElementById('slicerDomain').value = 'all';
            document.getElementById('slicerStatus').value = 'all';
            document.getElementById('slicerExecutor').value = 'all';
            document.getElementById('slicerSearch').value = '';

            activeDomain = 'all';
            activeStatus = 'all';
            activeExecutor = 'all';

            checkActiveFilters();
            renderLeadsVisual();
            renderProgramsList();
            showToast('تمت إعادة ضبط جميع الفلاتر');
        }

        function getFilteredPrograms() {
            const query = (document.getElementById('slicerSearch') ? document.getElementById('slicerSearch').value : '').trim().toLowerCase();

            return programsData.filter(function(p) {
                if (activeDomain !== 'all' && (!p.domain || !p.domain.includes(activeDomain))) return false;

                if (activeStatus !== 'all') {
                    const prog = parseInt(p.progress) || 0;
                    if (activeStatus === 'مكتمل' && prog < 100 && p.status !== 'مكتمل') return false;
                    if (activeStatus === 'جارٍ التنفيذ' && (prog === 0 || prog === 100)) return false;
                    if (activeStatus === 'لم يبدأ' && prog > 0) return false;
                }

                if (activeExecutor !== 'all') {
                    const ex = (p.executor || '').trim();
                    if (!ex.includes(activeExecutor) && !activeExecutor.includes(ex)) return false;
                }

                if (query) {
                    const searchStr = (p.id + ' ' + p.name + ' ' + p.domain + ' ' + p.executor + ' ' + p.detailed_goal + ' ' + p.indicator).toLowerCase();
                    if (!searchStr.includes(query)) return false;
                }

                return true;
            });
        }

        function switchView(view) {
            currentView = view;
            const cardsBtn = document.getElementById('viewCardsBtn');
            const tableBtn = document.getElementById('viewTableBtn');
            const cardsContainer = document.getElementById('cardsViewContainer');
            const tableContainer = document.getElementById('tableViewContainer');

            if (view === 'cards') {
                cardsBtn.className = 'px-3.5 py-1.5 rounded-lg bg-white text-emerald-900 shadow-sm transition font-bold';
                tableBtn.className = 'px-3.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition font-bold';
                cardsContainer.classList.remove('hidden');
                tableContainer.classList.add('hidden');
            } else {
                tableBtn.className = 'px-3.5 py-1.5 rounded-lg bg-white text-emerald-900 shadow-sm transition font-bold';
                cardsBtn.className = 'px-3.5 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition font-bold';
                cardsContainer.classList.add('hidden');
                tableContainer.classList.remove('hidden');
            }
            renderProgramsList();
        }

        function getDomainBadge(domain) {
            if (domain.includes('الإدارة المدرسية')) {
                return '<span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">الإدارة المدرسية</span>';
            } else if (domain.includes('نواتج التعلم')) {
                return '<span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">نواتج التعلم</span>';
            } else if (domain.includes('التعليم والتعلم')) {
                return '<span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">التعليم والتعلم</span>';
            } else {
                return '<span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-50 text-teal-700 border border-teal-200">' + domain + '</span>';
            }
        }

        function getDomainTopBorderColor(domain) {
            if (domain.includes('الإدارة المدرسية')) return 'border-t-indigo-600';
            if (domain.includes('نواتج التعلم')) return 'border-t-emerald-600';
            if (domain.includes('التعليم والتعلم')) return 'border-t-blue-600';
            return 'border-t-[#C5A059]';
        }

        function handleSliderInput(slider) {
            const id = slider.dataset.id;
            const val = slider.value;
            const disp = document.getElementById('progValDisplay_' + id);
            const bar = document.getElementById('progBar_' + id);
            if (disp) disp.textContent = val + '%';
            if (bar) bar.style.width = val + '%';
        }

        function renderCards(list) {
            const container = document.getElementById('cardsViewContainer');
            if (list.length === 0) {
                container.innerHTML = '<div class="col-span-full py-16 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">' +
                    '<div class="text-4xl mb-2">🔍</div>' +
                    '<p class="font-bold text-sm text-slate-700">لا توجد برامج مطابقة لخيارات التصفية الحالية</p>' +
                    '<button onclick="resetAllFilters()" class="mt-2 text-xs font-bold text-emerald-700 underline">إعادة ضبط جميع الفلاتر</button>' +
                '</div>';
                return;
            }

            container.innerHTML = list.map(function(p) {
                const prog = parseInt(p.progress) || 0;
                const link = p.barcode_link || '#';
                const hasValidLink = link && link !== '#' && link.startsWith('http');
                const borderColor = getDomainTopBorderColor(p.domain);

                return '<div class="program-card p-4.5 rounded-2xl flex flex-col justify-between space-y-3.5 border-t-4 ' + borderColor + '">' +
                    
                    '<!-- Top Info -->' +
                    '<div class="space-y-1.5">' +
                        '<div class="flex items-center justify-between gap-2">' +
                            '<span class="text-xs font-mono font-black text-slate-700 bg-slate-100 px-2 py-0.5 rounded">' + p.id + '</span>' +
                            getDomainBadge(p.domain) +
                        '</div>' +
                        '<h3 class="text-base font-black text-slate-900 leading-snug">' + p.name + '</h3>' +
                        '<p class="text-xs text-slate-600 line-clamp-2 leading-relaxed">' + (p.detailed_goal || p.program_goal || 'برنامج تشغيلي معتمد') + '</p>' +
                    '</div>' +

                    '<!-- Responsible & Target -->' +
                    '<div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-xs space-y-1.5">' +
                        '<div class="flex items-center justify-between text-slate-700">' +
                            '<span class="text-slate-400 font-bold">المنفذ:</span>' +
                            '<span class="font-black text-slate-800">' + p.executor + '</span>' +
                        '</div>' +
                        '<div class="flex items-center justify-between text-slate-700">' +
                            '<span class="text-slate-400 font-bold">المستهدف:</span>' +
                            '<span class="font-black text-emerald-800">' + (p.target_kpi || '95%') + '</span>' +
                        '</div>' +
                    '</div>' +

                    '<!-- Progress Slider -->' +
                    '<div class="space-y-1 pt-1">' +
                        '<div class="flex items-center justify-between text-xs">' +
                            '<span class="font-bold text-slate-700">نسبة الإنجاز:</span>' +
                            '<span class="font-black text-xs ' + (prog === 100 ? 'text-emerald-700' : 'text-blue-700') + '" id="progValDisplay_' + p.id + '">' + prog + '%</span>' +
                        '</div>' +
                        '<div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden">' +
                            '<div id="progBar_' + p.id + '" class="h-full transition-all duration-300 rounded-full ' + (prog === 100 ? 'bg-emerald-600' : (prog > 0 ? 'bg-blue-600' : 'bg-slate-300')) + '" style="width: ' + prog + '%"></div>' +
                        '</div>' +
                        '<input type="range" min="0" max="100" step="5" value="' + prog + '" ' +
                               'data-id="' + p.id + '" ' +
                               'onchange="updateProgramProgress(this.dataset.id, this.value)" ' +
                               'oninput="handleSliderInput(this)" ' +
                               'class="w-full accent-[#0D6E54] cursor-pointer h-1.5 bg-transparent no-print">' +
                    '</div>' +

                    '<!-- Action Buttons: WEB LINK & QR CODE -->' +
                    '<div class="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">' +
                        '<a href="' + link + '" target="_blank" rel="noopener noreferrer" ' +
                           'class="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-black rounded-xl transition shadow-xs ' +
                           (hasValidLink ? 'bg-[#0D6E54] hover:bg-[#064E3B] text-white' : 'bg-slate-200 text-slate-400 cursor-not-allowed') + '" ' +
                           'title="فتح مجلد الشواهد المباشر في Google Drive">' +
                            '<span>🔗 فتح الشواهد في Google Drive</span>' +
                        '</a>' +

                        '<button data-id="' + p.id + '" onclick="openQrModal(this.dataset.id)" ' +
                                'class="px-3 py-2 text-xs font-black bg-slate-800 hover:bg-slate-950 text-white rounded-xl flex items-center gap-1 shadow-xs transition" ' +
                                'title="عرض وتنزيل باركود الشواهد">' +
                            '<span>📱 QR</span>' +
                        '</button>' +
                    '</div>' +

                '</div>';
            }).join('');
        }

        function renderTable(list) {
            const tbody = document.getElementById('tableBodyContainer');
            tbody.innerHTML = list.map(function(p) {
                const prog = parseInt(p.progress) || 0;
                const link = p.barcode_link || '#';
                return '<tr class="hover:bg-slate-50 transition">' +
                    '<td class="py-3 px-3 font-mono font-bold text-slate-700">' + p.id + '</td>' +
                    '<td class="py-3 px-4 font-bold text-slate-900">' + p.name + '</td>' +
                    '<td class="py-3 px-3">' + getDomainBadge(p.domain) + '</td>' +
                    '<td class="py-3 px-3 font-medium text-slate-700">' + p.executor + '</td>' +
                    '<td class="py-3 px-3 text-emerald-800 font-bold">' + (p.target_kpi || '-') + '</td>' +
                    '<td class="py-3 px-3">' +
                        '<span class="px-2 py-0.5 rounded text-[10px] font-bold ' + (prog === 100 ? 'bg-emerald-100 text-emerald-800' : (prog > 0 ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800')) + '">' +
                            (prog === 100 ? 'مكتمل' : (prog > 0 ? 'جارٍ التنفيذ' : 'لم يبدأ')) +
                        '</span>' +
                    '</td>' +
                    '<td class="py-3 px-3 text-center">' +
                        '<div class="flex items-center justify-center gap-1.5">' +
                            '<span class="font-bold">' + prog + '%</span>' +
                            '<div class="w-12 bg-slate-200 h-1.5 rounded-full overflow-hidden">' +
                                '<div class="bg-emerald-600 h-full" style="width: ' + prog + '%"></div>' +
                            '</div>' +
                        '</div>' +
                    '</td>' +
                    '<td class="py-3 px-3 text-center">' +
                        '<a href="' + link + '" target="_blank" class="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-900 font-black underline text-xs">' +
                            '<span>فتح Google Drive</span>' +
                        '</a>' +
                    '</td>' +
                    '<td class="py-3 px-3 text-center">' +
                        '<button data-id="' + p.id + '" onclick="openQrModal(this.dataset.id)" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-800 font-bold text-xs">' +
                            'عرض QR' +
                        '</button>' +
                    '</td>' +
                '</tr>';
            }).join('');
        }

        function updateProgramProgress(id, newProgress) {
            const prog = programsData.find(function(p) { return p.id === id; });
            if (prog) {
                prog.progress = parseInt(newProgress);
                prog.status = prog.progress === 100 ? 'مكتمل' : (prog.progress > 0 ? 'جارٍ التنفيذ' : 'لم يبدأ');
                saveData();
                renderKPIs();
                renderLeadsVisual();
                renderExecutorsChart();
                showToast('تم تحديث نسبة إنجاز ' + prog.name + ' إلى ' + newProgress + '%');
            }
        }

        function openQrModal(id) {
            activeModalProgId = id;
            const prog = programsData.find(function(p) { return p.id === id; });
            if (!prog) return;

            document.getElementById('modalProgramName').textContent = prog.name;
            document.getElementById('modalProgramId').textContent = prog.id + ' • ' + prog.executor;
            document.getElementById('modalLinkInput').value = prog.barcode_link || '';

            generateQrCode(prog.barcode_link || ('https://mawahib-taiba.edu.sa/evidence/' + prog.id));
            document.getElementById('qrModal').classList.remove('hidden');
        }

        function closeQrModal() {
            document.getElementById('qrModal').classList.add('hidden');
            activeModalProgId = null;
        }

        function generateQrCode(url) {
            const container = document.getElementById('qrcodeCanvas');
            container.innerHTML = '';
            try {
                qrCodeInstance = new QRCode(container, {
                    text: url,
                    width: 160,
                    height: 160,
                    colorDark: '#0f172a',
                    colorLight: '#ffffff',
                    correctLevel: QRCode.CorrectLevel.H
                });
            } catch(e) {
                container.innerHTML = '<span class="text-xs text-red-500 font-bold">فشل توليد الباركود</span>';
            }
        }

        function saveModalLink() {
            if (!activeModalProgId) return;
            const newLink = document.getElementById('modalLinkInput').value.trim();
            const prog = programsData.find(function(p) { return p.id === activeModalProgId; });
            if (prog) {
                prog.barcode_link = newLink;
                saveData();
                generateQrCode(newLink || ('https://mawahib-taiba.edu.sa/evidence/' + prog.id));
                renderProgramsList();
                showToast('تم حفظ وتحديث رابط الشواهد والباركود بنجاح');
            }
        }

        function openModalWebLink() {
            const url = document.getElementById('modalLinkInput').value.trim();
            if (url) {
                window.open(url, '_blank');
            } else {
                alert('يرجى إدخال رابط صالح أولاً');
            }
        }

        function downloadQrImage() {
            const container = document.getElementById('qrcodeCanvas');
            const img = container.querySelector('img');
            const canvas = container.querySelector('canvas');
            
            let dataUrl = '';
            if (img && img.src) {
                dataUrl = img.src;
            } else if (canvas) {
                dataUrl = canvas.toDataURL('image/png');
            }

            if (dataUrl) {
                const a = document.createElement('a');
                a.href = dataUrl;
                a.download = 'QR_' + activeModalProgId + '_شواهد.png';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                showToast('تم تنزيل صورة الباركود بنجاح');
            } else {
                alert('تعذر استخراج صورة الباركود');
            }
        }

        function openAddProgramModal() {
            document.getElementById('addProgramModal').classList.remove('hidden');
        }

        function closeAddProgramModal() {
            document.getElementById('addProgramModal').classList.add('hidden');
            document.getElementById('addProgramForm').reset();
        }

        function submitNewProgram(e) {
            e.preventDefault();
            const newId = 'PRG-' + String(programsData.length + 1).padStart(3, '0');
            const name = document.getElementById('newProgName').value.trim();
            const domain = document.getElementById('newProgDomain').value;
            const executor = document.getElementById('newProgExecutor').value.trim();
            const target = document.getElementById('newProgTarget').value.trim() || '95%';
            const supporter = document.getElementById('newProgSupporter').value.trim() || '';
            const link = document.getElementById('newProgLink').value.trim() || ('https://mawahib-taiba.edu.sa/evidence/' + newId);

            const newProgram = {
                id: newId,
                name: name,
                domain: domain,
                executor: executor,
                supporter: supporter,
                target_kpi: target,
                start_date: '1448/03/17',
                end_date: '1448/12/30',
                status: 'لم يبدأ',
                progress: 0,
                barcode_link: link,
                detailed_goal: 'مبادرة مضافة حديثاً إلى الخطة التشغيلية'
            };

            programsData.push(newProgram);
            saveData();
            closeAddProgramModal();
            renderDashboard();
            showToast('تمت إضافة برنامج «' + name + '» بنجاح!');
        }

        function exportDataToCSV() {
            let csvContent = "\\uFEFF";
            csvContent += "معرّف البرنامج,اسم البرنامج,المجال,مسؤول التنفيذ,الجهة المساندة,المستهدف,حالة التنفيذ,نسبة الإنجاز,رابط الشواهد\\n";

            programsData.forEach(function(p) {
                const row = [
                    '"' + p.id + '"',
                    '"' + (p.name || '').replace(/"/g, '""') + '"',
                    '"' + (p.domain || '').replace(/"/g, '""') + '"',
                    '"' + (p.executor || '').replace(/"/g, '""') + '"',
                    '"' + (p.supporter || '').replace(/"/g, '""') + '"',
                    '"' + (p.target_kpi || '').replace(/"/g, '""') + '"',
                    '"' + (p.status || 'لم يبدأ') + '"',
                    '"' + (p.progress || 0) + '%"',
                    '"' + (p.barcode_link || '') + '"'
                ];
                csvContent += row.join(',') + '\\n';
            });

            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'متابعة_الخطة_التشغيلية_ابتدائية_مواهب_طيبة.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showToast('تم تصدير ملف الإكسل (CSV) بنجاح');
        }

        function showToast(msg) {
            const toast = document.getElementById('toastBox');
            document.getElementById('toastMsg').textContent = msg;
            toast.classList.remove('translate-y-20', 'opacity-0');
            toast.classList.add('translate-y-0', 'opacity-100');
            setTimeout(function() {
                toast.classList.add('translate-y-20', 'opacity-0');
                toast.classList.remove('translate-y-0', 'opacity-100');
            }, 3000);
        }
    </script>
</body>
</html>'''

final_html = template.replace('###LOGO_DATA_URI###', logo_data_uri).replace('###PROGRAMS_DATA_JSON###', programs_json_str)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(final_html)

print('Generated clean and validated index.html')
