import sys, json, base64

sys.stdout.reconfigure(encoding='utf-8')

# Read logo base64
with open('assets/page3_Image31.png', 'rb') as f:
    logo_b64 = base64.b64encode(f.read()).decode('utf-8')
logo_data_uri = f"data:image/png;base64,{logo_b64}"

# Read programs data
with open('programs_data.json', 'r', encoding='utf-8') as f:
    programs = json.load(f)

# Build the complete HTML
html_content = f'''<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم الخطة التشغيلية | ابتدائية مواهب طيبة (طفولة مبكرة)</title>
    
    <!-- Local & CDN Fallbacks -->
    <link rel="stylesheet" href="files/libs/tailwind.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Scripts: Chart.js, QRCode.js, SheetJS -->
    <script src="files/libs/chart.umd.min.js"></script>
    <script src="files/libs/qrcode.min.js"></script>
    <script src="files/libs/xlsx.full.min.js"></script>
    
    <style>
        :root {{
            --primary: #15803d;
            --primary-dark: #166534;
            --bg-calm: #f8fafc;
        }}
        body {{
            font-family: 'Tajawal', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f8fafc;
            color: #1e293b;
            scroll-behavior: smooth;
        }}
        ::-webkit-scrollbar {{
            width: 7px;
            height: 7px;
        }}
        ::-webkit-scrollbar-track {{
            background: #f1f5f9;
        }}
        ::-webkit-scrollbar-thumb {{
            background: #cbd5e1;
            border-radius: 4px;
        }}
        ::-webkit-scrollbar-thumb:hover {{
            background: #94a3b8;
        }}
        .card-clean {{
            background: #ffffff;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.03), 0 1px 2px -1px rgba(0, 0, 0, 0.03);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }}
        .card-clean:hover {{
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.03);
        }}
        .slicer-control {{
            height: 42px;
            border-radius: 0.75rem;
            border: 1px solid #cbd5e1;
            background-color: #ffffff;
            font-size: 0.825rem;
            color: #1e293b;
            padding-left: 0.75rem;
            padding-right: 0.75rem;
            transition: all 0.15s ease-in-out;
        }}
        .slicer-control:focus {{
            outline: none;
            border-color: #10b981;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.15);
        }}
        .dropzone-active {{
            border-color: #10b981 !important;
            background-color: #ecfdf5 !important;
        }}
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(4px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        .animate-fade {{
            animation: fadeIn 0.25s ease-out;
        }}
        @media print {{
            .no-print {{ display: none !important; }}
            body {{ background: white !important; }}
            .card-clean {{ box-shadow: none !important; border: 1px solid #cbd5e1 !important; break-inside: avoid; }}
        }}
    </style>
</head>
<body class="min-h-screen text-slate-800 flex flex-col justify-between" id="appBody">

    <!-- ===================== 1. CLEAN & SERENE HEADER ===================== -->
    <header class="bg-white border-b border-slate-200/80 sticky top-0 z-40 shadow-xs">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
            <div class="flex flex-col md:flex-row items-center justify-between gap-3">
                
                <!-- School & Ministry Brand (Clean & Uncluttered) -->
                <div class="flex items-center gap-3.5 w-full md:w-auto">
                    <!-- Ministry of Education Logo -->
                    <div class="h-12 w-16 flex items-center justify-center p-1 bg-white rounded-lg border border-slate-100 shadow-2xs shrink-0">
                        <img src="{logo_data_uri}" alt="شعار وزارة التعليم" class="h-full object-contain">
                    </div>

                    <!-- School Title & Subtitle -->
                    <div>
                        <div class="flex items-center gap-2">
                            <h1 class="text-lg sm:text-xl font-black text-slate-900 tracking-tight">ابتدائية مواهب طيبة <span class="text-emerald-700 font-semibold text-sm">(طفولة مبكرة)</span></h1>
                            <span class="px-2 py-0.5 text-[10px] font-bold bg-emerald-50 text-emerald-800 rounded-full border border-emerald-200">1448هـ</span>
                        </div>
                        <p class="text-xs text-slate-500 mt-0.5">لوحة متابعة الخطة التشغيلية السنوية • الإدارة العامة للتعليم بمنطقة المدينة المنورة</p>
                    </div>
                </div>

                <!-- Clean Actions Bar -->
                <div class="flex items-center gap-2 w-full md:w-auto justify-end no-print">
                    
                    <!-- Direct Excel Live Reader Input -->
                    <label class="cursor-pointer flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-xl border border-emerald-200/80 transition" title="قراءة وتحديث القيم مباشرة من ملف Excel">
                        <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                        <span>تحديث من ملف Excel</span>
                        <input type="file" id="excelFileInput" accept=".xlsx, .xls" class="hidden" onchange="handleExcelFileUpload(event)">
                    </label>

                    <button onclick="window.print()" class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition">
                        <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                        <span>طباعة</span>
                    </button>

                    <button onclick="exportDataToCSV()" class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition">
                        <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        <span>تصدير</span>
                    </button>

                    <button onclick="resetData()" title="استعادة القيم الأصلية من ملف الإكسل" class="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                    </button>
                </div>

            </div>
        </div>
    </header>

    <!-- ===================== MAIN CONTENT WRAPPER ===================== -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-6 w-full flex-grow">

        <!-- ===================== 2. EXECUTIVE SLICERS (ALIGNED & SYMMETRIC) ===================== -->
        <section class="card-clean p-4 rounded-2xl bg-white space-y-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    <h2 class="text-xs font-bold text-slate-800 uppercase tracking-wider">محددات التصفية والمتابعة (Slicers)</h2>
                </div>
                <div class="flex items-center gap-3">
                    <span class="text-xs text-slate-500 font-medium" id="syncStatusBadge">متصل ببيانات الإكسل 🟢</span>
                    <button id="resetFiltersBtn" onclick="resetAllFilters()" class="text-xs text-emerald-700 hover:underline font-bold hidden">إعادة ضبط الفلاتر ✕</button>
                </div>
            </div>

            <!-- Unified Slicer Grid (4 Perfectly Aligned Columns) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                
                <!-- Slicer 1: Domain -->
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 mb-1">المجال التعليمي:</label>
                    <select id="slicerDomain" onchange="applySlicers()" class="slicer-control w-full">
                        <option value="all">جميع المجالات (13 برنامج)</option>
                        <option value="الإدارة المدرسية">الإدارة المدرسية (8)</option>
                        <option value="نواتج التعلم">نواتج التعلم (4)</option>
                        <option value="التعليم والتعلم">التعليم والتعلم (2)</option>
                        <option value="البيئة المدرسية">البيئة المدرسية (2)</option>
                    </select>
                </div>

                <!-- Slicer 2: Status -->
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 mb-1">حالة التنفيذ:</label>
                    <select id="slicerStatus" onchange="applySlicers()" class="slicer-control w-full">
                        <option value="all">جميع الحالات</option>
                        <option value="مكتمل">مكتمل (100%)</option>
                        <option value="جارٍ التنفيذ">جارٍ التنفيذ</option>
                        <option value="لم يبدأ">لم يبدأ</option>
                    </select>
                </div>

                <!-- Slicer 3: Responsible Lead -->
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 mb-1">مسؤول التنفيذ:</label>
                    <select id="slicerExecutor" onchange="applySlicers()" class="slicer-control w-full">
                        <option value="all">جميع مسؤولي التنفيذ</option>
                        <option value="الموجهة الطلابية">الموجهة الطلابية (5 برامج)</option>
                        <option value="معلمات المواد المستهدفة">معلمات المواد المستهدفة (برنامجان)</option>
                        <option value="وكيلة المدرسة للشؤون الطلابية">وكيلة المدرسة للشؤون الطلابية</option>
                        <option value="منسقة الموهوبات / هيلة الجهني">منسقة الموهوبات / هيلة الجهني</option>
                        <option value="مديرة المدرسة">مديرة المدرسة</option>
                        <option value="سهيلة / عواطف">سهيلة / عواطف (الشؤون التعليمية)</option>
                        <option value="الموجهة الصحية">الموجهة الصحية</option>
                        <option value="الهيئة الإدارية">الهيئة الإدارية</option>
                    </select>
                </div>

                <!-- Slicer 4: Instant Search -->
                <div>
                    <label class="block text-[11px] font-bold text-slate-600 mb-1">البحث السريع:</label>
                    <div class="relative">
                        <input type="text" id="slicerSearch" oninput="applySlicers()" placeholder="اسم البرنامج، كود، أو مؤشر..." 
                               class="slicer-control w-full pr-8 pl-8">
                        <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-slate-400">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        </div>
                        <button onclick="document.getElementById('slicerSearch').value=''; applySlicers();" class="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400 hover:text-slate-600">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        </button>
                    </div>
                </div>

            </div>
        </section>

        <!-- ===================== 3. EXECUTIVE KPI CARDS (BALANCED & HARMONIC) ===================== -->
        <section class="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
            
            <!-- Overall Progress Gauge Card -->
            <div class="col-span-2 sm:col-span-1 card-clean p-4 rounded-2xl flex items-center justify-between bg-gradient-to-br from-emerald-50/60 to-white border-emerald-100">
                <div class="space-y-0.5">
                    <span class="text-[11px] font-bold text-emerald-800">معدل الإنجاز العام</span>
                    <h3 class="text-2xl font-black text-emerald-950"><span id="kpiOverallPercent">0</span><span class="text-base text-emerald-700 mr-0.5">%</span></h3>
                    <p class="text-[10px] text-slate-500">متوسط تقدم الخطة</p>
                </div>
                <div class="relative w-14 h-14 shrink-0">
                    <svg class="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
                        <path class="text-emerald-100" stroke-width="3.5" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                        <path id="gaugeProgressPath" class="text-emerald-600" stroke-dasharray="0, 100" stroke-width="3.5" stroke-linecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    </svg>
                    <div class="absolute inset-0 flex items-center justify-center font-bold text-[11px] text-emerald-900">
                        <span id="gaugeText">0%</span>
                    </div>
                </div>
            </div>

            <!-- Total Programs Card -->
            <div class="card-clean p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-bold text-slate-700">إجمالي البرامج</span>
                    <span class="p-1 bg-slate-100 text-slate-600 rounded-md text-[10px]">1448هـ</span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-slate-800" id="kpiTotalPrograms">13</div>
                    <span class="text-[10px] text-slate-500">برنامج ومبادرة معتمدة</span>
                </div>
            </div>

            <!-- Completed Card -->
            <div class="card-clean p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-bold text-emerald-700">مكتمل</span>
                    <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-emerald-600" id="kpiCompletedPrograms">0</div>
                    <span class="text-[10px] text-slate-500">منجز بنسبة 100%</span>
                </div>
            </div>

            <!-- In Progress Card -->
            <div class="card-clean p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-bold text-blue-700">جارٍ التنفيذ</span>
                    <span class="w-2 h-2 rounded-full bg-blue-500"></span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-blue-600" id="kpiInProgressPrograms">0</div>
                    <span class="text-[10px] text-slate-500">قيد العمل والمتابعة</span>
                </div>
            </div>

            <!-- Not Started Card -->
            <div class="card-clean p-4 rounded-2xl flex flex-col justify-between">
                <div class="flex items-center justify-between text-slate-400">
                    <span class="text-xs font-bold text-amber-700">لم يبدأ</span>
                    <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                </div>
                <div class="mt-2">
                    <div class="text-2xl font-black text-amber-600" id="kpiPendingPrograms">13</div>
                    <span class="text-[10px] text-slate-500">بانتظار بدء الجدولة</span>
                </div>
            </div>

        </section>

        <!-- ===================== 4. VISUAL FOR المسؤولين (REQUESTED VISUAL) ===================== -->
        <section class="card-clean p-5 rounded-2xl space-y-4">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2.5">
                    <div class="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    </div>
                    <div>
                        <h2 class="text-sm sm:text-base font-bold text-slate-900">فريق العمل ومسؤولو التنفيذ (المسؤولين)</h2>
                        <p class="text-xs text-slate-500">استعراض بصري لمسؤولي ومسؤولات البرامج، ونسب الإنجاز المحققة لكل مسؤول (انقر على أي بطاقة لعرض برامجه فوراً)</p>
                    </div>
                </div>

                <!-- Selected Lead Indicator -->
                <div id="activeLeadFilterTag" class="hidden items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-200 text-xs font-bold">
                    <span>محدد حالياً: <span id="activeLeadName"></span></span>
                    <button onclick="filterByLead('all')" class="text-emerald-600 hover:text-emerald-900">✕</button>
                </div>
            </div>

            <!-- Leads Visual Cards Grid -->
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3" id="leadsCardsContainer">
                <!-- Dynamically populated via JS -->
            </div>

            <!-- Leads Comparison Bar Chart -->
            <div class="pt-3 border-t border-slate-100">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold text-slate-700">مقارنة أداء مسؤولي التنفيذ (عدد البرامج vs نسبة الإنجاز):</span>
                </div>
                <div class="h-56 sm:h-64 w-full bg-slate-50/70 p-3 rounded-xl border border-slate-100">
                    <canvas id="executorsChart"></canvas>
                </div>
            </div>
        </section>

        <!-- ===================== 5. OPERATIONAL PLAN PROGRAMS HUB ===================== -->
        <section class="space-y-4">
            
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2">
                    <h2 class="text-base sm:text-lg font-black text-slate-900">خطة البرامج والمبادرات وشواهد التنفيذ</h2>
                    <span class="text-xs font-semibold px-2.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-full" id="programsCountBadge">13 برنامج</span>
                </div>

                <div class="flex items-center gap-2 no-print">
                    <!-- Cards / Table View Toggle -->
                    <div class="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs">
                        <button id="viewCardsBtn" onclick="switchView('cards')" class="px-3 py-1.5 rounded-lg font-bold bg-white text-emerald-800 shadow-2xs flex items-center gap-1.5 transition">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                            <span>بطاقات</span>
                        </button>
                        <button id="viewTableBtn" onclick="switchView('table')" class="px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                            <span>جدول</span>
                        </button>
                    </div>

                    <button onclick="openAddProgramModal()" class="px-3.5 py-1.5 text-xs font-bold bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl shadow-xs flex items-center gap-1.5 transition">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                        <span>إضافة برنامج</span>
                    </button>
                </div>
            </div>

            <!-- CARDS VIEW (Default) -->
            <div id="cardsViewContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Generated by JS -->
            </div>

            <!-- TABLE VIEW -->
            <div id="tableViewContainer" class="card-clean rounded-2xl overflow-hidden hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 text-right text-xs">
                        <thead class="bg-slate-50 text-slate-700 font-bold">
                            <tr>
                                <th class="py-3 px-3">المعرّف</th>
                                <th class="py-3 px-4">البرنامج / المبادرة</th>
                                <th class="py-3 px-3">المجال</th>
                                <th class="py-3 px-3">مسؤول التنفيذ</th>
                                <th class="py-3 px-3">المستهدف</th>
                                <th class="py-3 px-3">الحالة</th>
                                <th class="py-3 px-3 text-center">نسبة الإنجاز</th>
                                <th class="py-3 px-3 text-center">رابط الشواهد (ويب)</th>
                                <th class="py-3 px-3 text-center">الباركود (QR)</th>
                            </tr>
                        </thead>
                        <tbody id="tableBodyContainer" class="divide-y divide-slate-100 bg-white">
                            <!-- Generated by JS -->
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

    </main>

    <!-- ===================== FOOTER ===================== -->
    <footer class="bg-white border-t border-slate-200 py-3.5 text-center text-xs text-slate-500 mt-6">
        <div class="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p>الخطة التشغيلية السنوية • ابتدائية مواهب طيبة (طفولة مبكرة) • العام الدراسي 1448هـ</p>
            <p class="text-slate-400">لوحة المتابعة التنفيذية الشاملة | مترابطة مع ملف الإكسل</p>
        </div>
    </footer>

    <!-- ===================== MODAL: QR CODE & EVIDENCE ===================== -->
    <div id="qrModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-fade">
            
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2">
                    <div class="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
                    </div>
                    <div>
                        <h3 class="text-sm font-bold text-slate-900" id="modalProgramName">باركود شواهد البرنامج</h3>
                        <span class="text-xs text-slate-500" id="modalProgramId">PRG-000</span>
                    </div>
                </div>
                <button onclick="closeQrModal()" class="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            <!-- QR Container -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col items-center justify-center space-y-2">
                <div id="qrcodeCanvas" class="bg-white p-3 rounded-xl shadow-xs border border-slate-200"></div>
                <p class="text-[11px] text-slate-500 font-medium text-center">امسح الباركود بكاميرا الجوال للانتقال لملف الشواهد في Google Drive</p>
            </div>

            <!-- Web Link Input & Update -->
            <div class="space-y-1.5">
                <label class="block text-xs font-bold text-slate-700">رابط الشواهد على الويب (Google Drive):</label>
                <div class="flex items-center gap-2">
                    <input type="url" id="modalLinkInput" class="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50" placeholder="https://drive.google.com/...">
                    <button onclick="saveModalLink()" class="px-3 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl transition">حفظ الرابط</button>
                </div>
            </div>

            <!-- Modal Action Buttons -->
            <div class="grid grid-cols-2 gap-2 pt-1">
                <button onclick="openModalWebLink()" class="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                    <span>فتح في الويب</span>
                </button>
                <button onclick="downloadQrImage()" class="flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-900 text-white rounded-xl transition">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    <span>تنزيل الباركود PNG</span>
                </button>
            </div>
        </div>
    </div>

    <!-- ===================== MODAL: ADD NEW PROGRAM ===================== -->
    <div id="addProgramModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs hidden">
        <div class="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-4 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 class="text-sm font-bold text-slate-800">إضافة برنامج أو مبادرة تشغيلية جديدة</h3>
                <button onclick="closeAddProgramModal()" class="text-slate-400 hover:text-slate-600 p-1 rounded-lg">✕</button>
            </div>

            <form id="addProgramForm" onsubmit="submitNewProgram(event)" class="space-y-3 text-xs">
                <div>
                    <label class="block font-bold text-slate-700 mb-1">اسم البرنامج / المبادرة:</label>
                    <input type="text" id="newProgName" required class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white" placeholder="مثال: تعزيز المهارات الرقمية">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">المجال:</label>
                        <select id="newProgDomain" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50">
                            <option value="الإدارة المدرسية">الإدارة المدرسية</option>
                            <option value="نواتج التعلم">نواتج التعلم</option>
                            <option value="التعليم والتعلم">التعليم والتعلم</option>
                            <option value="البيئة المدرسية">البيئة المدرسية</option>
                        </select>
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">مسؤول التنفيذ:</label>
                        <input type="text" id="newProgExecutor" required class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="مثال: الموجهة الطلابية">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">المستهدف والمؤشر:</label>
                        <input type="text" id="newProgTarget" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="مثال: 95% من الطالبات">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 mb-1">الجهة المساندة:</label>
                        <input type="text" id="newProgSupporter" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="مثال: رائدة النشاط / المعلمات">
                    </div>
                </div>

                <div>
                    <label class="block font-bold text-slate-700 mb-1">رابط الشواهد على الويب (Google Drive):</label>
                    <input type="url" id="newProgLink" class="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50" placeholder="https://drive.google.com/...">
                </div>

                <div class="pt-2 flex justify-end gap-2">
                    <button type="button" onclick="closeAddProgramModal()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition">إلغاء</button>
                    <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition">إضافة البرنامج</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ===================== TOAST NOTIFICATION ===================== -->
    <div id="toastBox" class="fixed bottom-5 left-5 z-50 bg-slate-900 text-white text-xs px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 transform translate-y-20 opacity-0 transition-all duration-300 pointer-events-none">
        <span id="toastMsg">تم الحفظ بنجاح</span>
    </div>

    <!-- ===================== JAVASCRIPT LOGIC ===================== -->
    <script>
        // Exact bundled initial data from Excel
        const INITIAL_PROGRAMS = ''' + json.dumps(programs, ensure_ascii=False) + ''';

        let programsData = [];
        let activeDomain = 'all';
        let activeStatus = 'all';
        let activeExecutor = 'all';
        let currentView = 'cards';
        let activeModalProgId = null;
        let qrCodeInstance = null;
        let comparisonChart = null;

        // Key leads metadata from the school's operational plan
        const LEADS_META = [
            {{ name: 'عيدة الرشيدي', role: 'مديرة المدرسة / رئيسة الفريق', icon: '👑', color: 'emerald' }},
            {{ name: 'أسماء العارضي', role: 'وكيلة شؤون الطالبات / نائبة', icon: '📋', color: 'blue' }},
            {{ name: 'سامية الحازمي – مارية الجهني', role: 'الموجهة الطلابية', icon: '💡', color: 'indigo' }},
            {{ name: 'هيلة الجهني', role: 'منسقة الموهوبات', icon: '⭐', color: 'amber' }},
            {{ name: 'معلمات المواد المستهدفة', role: 'لجنة التحصيل الدراسي', icon: '📚', color: 'teal' }},
            {{ name: 'الموجهة الصحية', role: 'الصحة المدرسية', icon: '🩺', color: 'rose' }}
        ];

        document.addEventListener('DOMContentLoaded', () => {{
            loadProgramsData();
            tryAutoReadExcel();
            renderDashboard();
            setupDragAndDrop();
        }});

        function loadProgramsData() {{
            const saved = localStorage.getItem('mawahib_operational_plan_v2');
            if (saved) {{
                try {{
                    programsData = JSON.parse(saved);
                }} catch(e) {{
                    programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
                }}
            }} else {{
                programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
            }}
        }}

        function saveData() {{
            localStorage.setItem('mawahib_operational_plan_v2', JSON.stringify(programsData));
        }}

        function resetData() {{
            if (confirm('هل ترغب في إعادة ضبط البيانات إلى القيم المعتمدة من ملف الإكسل؟')) {{
                localStorage.removeItem('mawahib_operational_plan_v2');
                programsData = JSON.parse(JSON.stringify(INITIAL_PROGRAMS));
                renderDashboard();
                showToast('تمت استعادة البيانات الأصلية بنجاح');
            }}
        }}

        // ===================== DYNAMIC EXCEL READING (SheetJS) =====================
        function tryAutoReadExcel() {{
            // Attempt to fetch local excel file if allowed by browser
            fetch('files/موهبة طيبة- طفولة مبكرة.xlsx')
                .then(res => {{
                    if (res.ok) return res.arrayBuffer();
                    throw new Error('Local fetch not allowed');
                }})
                .then(data => {{
                    parseExcelArrayBuffer(data, false);
                    document.getElementById('syncStatusBadge').textContent = 'قراءة تلقائية من ملف الإكسل 🟢';
                }})
                .catch(err => {{
                    // Fallback to loaded memory data
                    document.getElementById('syncStatusBadge').textContent = 'مطابق لقيم ملف الإكسل 🟢';
                }});
        }}

        function handleExcelFileUpload(event) {{
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(e) {{
                const data = new Uint8Array(e.target.result);
                parseExcelArrayBuffer(data, true);
            }};
            reader.readAsArrayBuffer(file);
        }}

        function setupDragAndDrop() {{
            const body = document.getElementById('appBody');
            ['dragenter', 'dragover'].forEach(eventName => {{
                body.addEventListener(eventName, (e) => {{
                    e.preventDefault();
                    e.stopPropagation();
                    body.classList.add('dropzone-active');
                }}, false);
            }});
            ['dragleave', 'drop'].forEach(eventName => {{
                body.addEventListener(eventName, (e) => {{
                    e.preventDefault();
                    e.stopPropagation();
                    body.classList.remove('dropzone-active');
                }}, false);
            }});
            body.addEventListener('drop', (e) => {{
                const dt = e.dataTransfer;
                const files = dt.files;
                if (files && files.length > 0 && files[0].name.endsWith('.xlsx')) {{
                    const reader = new FileReader();
                    reader.onload = function(evt) {{
                        parseExcelArrayBuffer(new Uint8Array(evt.target.result), true);
                    }};
                    reader.readAsArrayBuffer(files[0]);
                }}
            }});
        }}

        function parseExcelArrayBuffer(data, notify) {{
            try {{
                const workbook = XLSX.read(data, {{ type: 'array' }});
                
                // Read from sheet 'البرامج والمبادرات' or 'متابعة التنفيذ'
                const targetSheetName = workbook.SheetNames.includes('متابعة التنفيذ') ? 'متابعة التنفيذ' : workbook.SheetNames[0];
                const ws = workbook.Sheets[targetSheetName];
                const rows = XLSX.utils.sheet_to_json(ws, {{ header: 1 }});

                // Check if this is متابعة التنفيذ or البرامج والمبادرات
                let updatedCount = 0;
                rows.forEach(r => {{
                    if (r && r.length > 1) {{
                        const progName = String(r[0] || '').trim();
                        // Find matching program
                        const match = programsData.find(p => p.name.includes(progName) || progName.includes(p.name));
                        if (match) {{
                            if (r[8] && String(r[8]).trim() !== '') match.status = String(r[8]).trim();
                            if (r[9] !== undefined && r[9] !== '') {{
                                let pVal = parseFloat(r[9]);
                                if (pVal <= 1.0 && pVal > 0) pVal = Math.round(pVal * 100);
                                if (!isNaN(pVal)) match.progress = parseInt(pVal);
                            }}
                            if (r[10] && String(r[10]).startsWith('http')) match.barcode_link = String(r[10]).trim();
                            updatedCount++;
                        }}
                    }}
                }});

                saveData();
                renderDashboard();
                if (notify) {{
                    showToast(`تمت قراءة وتحديث ${{updatedCount}} برنامج من ملف الإكسل بنجاح!`);
                }}
            }} catch(err) {{
                console.error('Error parsing excel:', err);
                if (notify) alert('تعذر قراءة ملف الإكسل، يرجى التأكد من صيغة الملف.');
            }}
        }}

        function renderDashboard() {{
            renderKPIs();
            renderLeadsVisual();
            renderExecutorsChart();
            renderProgramsList();
        }}

        // ===================== KPI CALCULATIONS =====================
        function renderKPIs() {{
            const total = programsData.length;
            let sumProgress = 0;
            let completed = 0;
            let inProgress = 0;
            let pending = 0;

            programsData.forEach(p => {{
                const prog = parseInt(p.progress) || 0;
                sumProgress += prog;
                if (prog === 100 || p.status === 'مكتمل') {{
                    completed++;
                }} else if (prog > 0 || p.status === 'جارٍ التنفيذ') {{
                    inProgress++;
                }} else {{
                    pending++;
                }}
            }});

            const avgProgress = total > 0 ? Math.round(sumProgress / total) : 0;

            document.getElementById('kpiTotalPrograms').textContent = total;
            document.getElementById('kpiCompletedPrograms').textContent = completed;
            document.getElementById('kpiInProgressPrograms').textContent = inProgress;
            document.getElementById('kpiPendingPrograms').textContent = pending;
            document.getElementById('kpiOverallPercent').textContent = avgProgress;
            document.getElementById('gaugeText').textContent = avgProgress + '%';

            const path = document.getElementById('gaugeProgressPath');
            if (path) {{
                path.setAttribute('stroke-dasharray', `${{avgProgress}}, 100`);
            }}
        }}

        // ===================== VISUAL FOR المسؤولين =====================
        function renderLeadsVisual() {{
            const container = document.getElementById('leadsCardsContainer');
            if (!container) return;

            // Map actual data by lead
            const leadsSummary = LEADS_META.map(lead => {{
                const matchingProgs = programsData.filter(p => {{
                    const ex = (p.executor || '').trim();
                    return ex.includes(lead.name) || lead.name.includes(ex) || (lead.name.includes('الموجهة الطلابية') && ex.includes('الموجهة الطلابية'));
                }});

                const count = matchingProgs.length;
                let sum = 0;
                matchingProgs.forEach(p => sum += (parseInt(p.progress) || 0));
                const avg = count > 0 ? Math.round(sum / count) : 0;

                return {{
                    ...lead,
                    programsCount: count,
                    avgProgress: avg
                }};
            }});

            container.innerHTML = leadsSummary.map(lead => {{
                const isSelected = activeExecutor !== 'all' && (activeExecutor.includes(lead.name) || lead.name.includes(activeExecutor));
                return `
                    <div onclick="filterByLead('${{lead.name}}')" 
                         class="p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-right ${{
                             isSelected 
                                ? 'bg-emerald-50 border-emerald-500 shadow-md ring-2 ring-emerald-500/20' 
                                : 'bg-slate-50/70 hover:bg-white hover:shadow-xs border-slate-200'
                         }}">
                        
                        <div class="flex items-center justify-between mb-2">
                            <span class="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-sm shadow-2xs">
                                ${{lead.icon}}
                            </span>
                            <span class="text-[10px] font-bold px-1.5 py-0.5 rounded-full ${{
                                lead.programsCount > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                            }}">
                                ${{lead.programsCount}} برامج
                            </span>
                        </div>

                        <div>
                            <h3 class="text-xs font-bold text-slate-800 line-clamp-1">${{lead.name}}</h3>
                            <p class="text-[10px] text-slate-500 line-clamp-1 mt-0.5">${{lead.role}}</p>
                        </div>

                        <div class="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                            <span class="text-slate-400 text-[10px]">الإنجاز:</span>
                            <span class="font-black ${{lead.avgProgress > 0 ? 'text-emerald-700' : 'text-slate-400'}}">${{lead.avgProgress}}%</span>
                        </div>

                        <div class="w-full bg-slate-200/80 h-1.5 rounded-full mt-1 overflow-hidden">
                            <div class="bg-emerald-600 h-full rounded-full transition-all duration-300" style="width: ${{lead.avgProgress}}%"></div>
                        </div>

                    </div>
                `;
            }}).join('');
        }}

        function filterByLead(leadName) {{
            const tag = document.getElementById('activeLeadFilterTag');
            const tagText = document.getElementById('activeLeadName');

            if (leadName === 'all' || activeExecutor === leadName) {{
                activeExecutor = 'all';
                document.getElementById('slicerExecutor').value = 'all';
                tag.classList.add('hidden');
            }} else {{
                activeExecutor = leadName;
                document.getElementById('slicerExecutor').value = leadName;
                tag.classList.remove('hidden');
                tagText.textContent = leadName;
            }}

            checkActiveFilters();
            renderLeadsVisual();
            renderProgramsList();
        }}

        // ===================== EXECUTORS CHART =====================
        function renderExecutorsChart() {{
            const execMap = {{}};
            programsData.forEach(p => {{
                const ex = (p.executor || 'غير محدد').trim();
                if (!execMap[ex]) {{
                    execMap[ex] = {{ count: 0, sumProgress: 0 }};
                }}
                execMap[ex].count += 1;
                execMap[ex].sumProgress += (parseInt(p.progress) || 0);
            }});

            const labels = [];
            const counts = [];
            const averages = [];

            for (const [ex, data] of Object.entries(execMap)) {{
                labels.push(ex.length > 20 ? ex.substring(0, 18) + '...' : ex);
                counts.push(data.count);
                averages.push(Math.round(data.sumProgress / data.count));
            }}

            const ctx = document.getElementById('executorsChart');
            if (ctx) {{
                if (comparisonChart) comparisonChart.destroy();

                comparisonChart = new Chart(ctx, {{
                    type: 'bar',
                    data: {{
                        labels: labels,
                        datasets: [
                            {{
                                label: 'عدد البرامج المسندة',
                                data: counts,
                                backgroundColor: '#10b981',
                                borderRadius: 6,
                                yAxisID: 'y'
                            }},
                            {{
                                label: 'متوسط نسبة الإنجاز (%)',
                                data: averages,
                                backgroundColor: '#0284c7',
                                borderRadius: 6,
                                yAxisID: 'y1'
                            }}
                        ]
                    }},
                    options: {{
                        responsive: true,
                        maintainAspectRatio: false,
                        interaction: {{ mode: 'index', intersect: false }},
                        plugins: {{
                            legend: {{
                                position: 'top',
                                labels: {{ font: {{ family: 'Tajawal', size: 11 }}, boxWidth: 12 }}
                            }},
                            tooltip: {{ rtl: true, titleFont: {{ family: 'Tajawal' }}, bodyFont: {{ family: 'Tajawal' }} }}
                        }},
                        scales: {{
                            x: {{ ticks: {{ font: {{ family: 'Tajawal', size: 10 }} }}, grid: {{ display: false }} }},
                            y: {{
                                type: 'linear',
                                display: true,
                                position: 'right',
                                title: {{ display: true, text: 'عدد البرامج', font: {{ family: 'Tajawal', size: 10 }} }},
                                min: 0,
                                ticks: {{ stepSize: 1 }}
                            }},
                            y1: {{
                                type: 'linear',
                                display: true,
                                position: 'left',
                                title: {{ display: true, text: 'الإنجاز %', font: {{ family: 'Tajawal', size: 10 }} }},
                                min: 0,
                                max: 100,
                                grid: {{ drawOnChartArea: false }}
                            }}
                        }}
                    }}
                }});
            }}
        }}

        // ===================== SLICERS & FILTER LOGIC =====================
        function applySlicers() {{
            activeDomain = document.getElementById('slicerDomain').value;
            activeStatus = document.getElementById('slicerStatus').value;
            activeExecutor = document.getElementById('slicerExecutor').value;
            
            checkActiveFilters();
            renderLeadsVisual();
            renderProgramsList();
        }}

        function checkActiveFilters() {{
            const resetBtn = document.getElementById('resetFiltersBtn');
            const searchVal = document.getElementById('slicerSearch')?.value || '';
            const isFiltered = (activeDomain !== 'all' || activeStatus !== 'all' || activeExecutor !== 'all' || searchVal.trim() !== '');

            if (isFiltered) {{
                resetBtn.classList.remove('hidden');
            }} else {{
                resetBtn.classList.add('hidden');
                document.getElementById('activeLeadFilterTag')?.classList.add('hidden');
            }}
        }}

        function resetAllFilters() {{
            document.getElementById('slicerDomain').value = 'all';
            document.getElementById('slicerStatus').value = 'all';
            document.getElementById('slicerExecutor').value = 'all';
            document.getElementById('slicerSearch').value = '';

            activeDomain = 'all';
            activeStatus = 'all';
            activeExecutor = 'all';

            checkActiveFilters();
            renderLeadsVisual();
            renderProgramsList();
            showToast('تمت إعادة ضبط جميع الفلاتر');
        }}

        function getFilteredPrograms() {{
            const query = (document.getElementById('slicerSearch')?.value || '').trim().toLowerCase();

            return programsData.filter(p => {{
                if (activeDomain !== 'all' && (!p.domain || !p.domain.includes(activeDomain))) return false;

                if (activeStatus !== 'all') {{
                    const prog = parseInt(p.progress) || 0;
                    if (activeStatus === 'مكتمل' && prog < 100 && p.status !== 'مكتمل') return false;
                    if (activeStatus === 'جارٍ التنفيذ' && (prog === 0 || prog === 100)) return false;
                    if (activeStatus === 'لم يبدأ' && prog > 0) return false;
                }}

                if (activeExecutor !== 'all') {{
                    const ex = (p.executor || '').trim();
                    if (!ex.includes(activeExecutor) && !activeExecutor.includes(ex)) return false;
                }}

                if (query) {{
                    const searchStr = `${{p.id}} ${{p.name}} ${{p.domain}} ${{p.executor}} ${{p.detailed_goal}} ${{p.indicator}}`.toLowerCase();
                    if (!searchStr.includes(query)) return false;
                }}

                return true;
            }});
        }}

        // ===================== VIEW SWITCHER =====================
        function switchView(view) {{
            currentView = view;
            const cardsBtn = document.getElementById('viewCardsBtn');
            const tableBtn = document.getElementById('viewTableBtn');
            const cardsContainer = document.getElementById('cardsViewContainer');
            const tableContainer = document.getElementById('tableViewContainer');

            if (view === 'cards') {{
                cardsBtn.className = 'px-3 py-1.5 rounded-lg font-bold bg-white text-emerald-800 shadow-2xs flex items-center gap-1.5 transition';
                tableBtn.className = 'px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition';
                cardsContainer.classList.remove('hidden');
                tableContainer.classList.add('hidden');
            }} else {{
                tableBtn.className = 'px-3 py-1.5 rounded-lg font-bold bg-white text-emerald-800 shadow-2xs flex items-center gap-1.5 transition';
                cardsBtn.className = 'px-3 py-1.5 rounded-lg font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1.5 transition';
                cardsContainer.classList.add('hidden');
                tableContainer.classList.remove('hidden');
            }}
            renderProgramsList();
        }}

        // ===================== RENDER PROGRAMS LIST =====================
        function renderProgramsList() {{
            const filtered = getFilteredPrograms();
            document.getElementById('programsCountBadge').textContent = `${{filtered.length}} من ${{programsData.length}} برنامج`;

            if (currentView === 'cards') {{
                renderCards(filtered);
            }} else {{
                renderTable(filtered);
            }}
        }}

        function getDomainBadge(domain) {{
            if (domain.includes('الإدارة المدرسية')) {{
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200/60">الإدارة المدرسية</span>';
            }} else if (domain.includes('نواتج التعلم')) {{
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">نواتج التعلم</span>';
            }} else if (domain.includes('التعليم والتعلم')) {{
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60">التعليم والتعلم</span>';
            }} else {{
                return '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200/60">' + domain + '</span>';
            }}
        }}

        function renderCards(list) {{
            const container = document.getElementById('cardsViewContainer');
            if (list.length === 0) {{
                container.innerHTML = `
                    <div class="col-span-full py-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
                        <svg class="w-10 h-10 mx-auto mb-2 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        <p class="font-bold text-xs">لا توجد برامج مطابقة لخيارات التصفية الحالية</p>
                    </div>
                `;
                return;
            }}

            container.innerHTML = list.map(p => {{
                const prog = parseInt(p.progress) || 0;
                const link = p.barcode_link || '#';
                const hasValidLink = link && link !== '#' && link.startsWith('http');

                return `
                    <div class="card-clean p-4 rounded-2xl flex flex-col justify-between space-y-3 relative overflow-hidden group">
                        
                        <!-- Top Metadata -->
                        <div class="space-y-1">
                            <div class="flex items-center justify-between gap-2">
                                <span class="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">${{p.id}}</span>
                                ${{getDomainBadge(p.domain)}}
                            </div>
                            <h3 class="text-sm font-bold text-slate-900 group-hover:text-emerald-700 transition leading-snug">${{p.name}}</h3>
                            <p class="text-xs text-slate-500 line-clamp-2 leading-relaxed">${{p.detailed_goal || p.program_goal || 'برنامج تشغيلي معتمد'}}</p>
                        </div>

                        <!-- Responsible & Target Info -->
                        <div class="bg-slate-50/90 p-2.5 rounded-xl border border-slate-100 text-xs space-y-1">
                            <div class="flex items-center justify-between text-slate-600">
                                <span class="text-slate-400 font-medium">المنفذ:</span>
                                <span class="font-bold text-slate-800">${{p.executor}}</span>
                            </div>
                            <div class="flex items-center justify-between text-slate-600">
                                <span class="text-slate-400 font-medium">المستهدف:</span>
                                <span class="font-medium text-emerald-700">${{p.target_kpi || '95%'}}</span>
                            </div>
                        </div>

                        <!-- Progress Bar & Slider -->
                        <div class="space-y-1 pt-1">
                            <div class="flex items-center justify-between text-xs">
                                <span class="font-bold text-slate-700">نسبة الإنجاز:</span>
                                <span class="font-black text-xs ${{prog === 100 ? 'text-emerald-600' : 'text-blue-700'}}" id="progValDisplay_${{p.id}}">${{prog}}%</span>
                            </div>
                            <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                                <div id="progBar_${{p.id}}" class="h-full transition-all duration-300 rounded-full ${{
                                    prog === 100 ? 'bg-emerald-500' : (prog > 0 ? 'bg-blue-500' : 'bg-slate-300')
                                }}" style="width: ${{prog}}%"></div>
                            </div>
                            <input type="range" min="0" max="100" step="5" value="${{prog}}" 
                                   onchange="updateProgramProgress('${{p.id}}', this.value)"
                                   oninput="document.getElementById('progValDisplay_${{p.id}}').textContent = this.value + '%'; document.getElementById('progBar_${{p.id}}').style.width = this.value + '%';"
                                   class="w-full accent-emerald-600 cursor-pointer h-1 bg-transparent no-print">
                        </div>

                        <!-- Action Buttons: WEB LINK & QR CODE -->
                        <div class="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                            <!-- Web Navigation Button (Google Drive Link) -->
                            <a href="${{link}}" target="_blank" rel="noopener noreferrer" 
                               class="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition ${{
                                   hasValidLink ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200/80 shadow-2xs' : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                               }}" title="فتح ملف الشواهد المباشر على الويب">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                                <span>فتح الشواهد على الويب</span>
                            </a>

                            <!-- Barcode / QR Button -->
                            <button onclick="openQrModal('${{p.id}}')" 
                                    class="px-3 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-900 text-white rounded-xl flex items-center gap-1 shadow-2xs transition"
                                    title="عرض وتوليد وتنزيل باركود الشواهد">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"/></svg>
                                <span>الباركود</span>
                            </button>
                        </div>

                    </div>
                `;
            }}).join('');
        }}

        function renderTable(list) {{
            const tbody = document.getElementById('tableBodyContainer');
            tbody.innerHTML = list.map(p => {{
                const prog = parseInt(p.progress) || 0;
                const link = p.barcode_link || '#';
                return `
                    <tr class="hover:bg-slate-50/80 transition">
                        <td class="py-2.5 px-3 font-mono font-bold text-slate-500">${{p.id}}</td>
                        <td class="py-2.5 px-4 font-bold text-slate-800">${{p.name}}</td>
                        <td class="py-2.5 px-3">${{getDomainBadge(p.domain)}}</td>
                        <td class="py-2.5 px-3 text-slate-700">${{p.executor}}</td>
                        <td class="py-2.5 px-3 text-emerald-700 font-medium">${{p.target_kpi || '-'}}</td>
                        <td class="py-2.5 px-3">
                            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${{
                                prog === 100 ? 'bg-emerald-100 text-emerald-800' : (prog > 0 ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800')
                            }}">${{prog === 100 ? 'مكتمل' : (prog > 0 ? 'جارٍ التنفيذ' : 'لم يبدأ')}}</span>
                        </td>
                        <td class="py-2.5 px-3 text-center">
                            <div class="flex items-center justify-center gap-1.5">
                                <span class="font-bold">${{prog}}%</span>
                                <div class="w-12 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                                    <div class="bg-emerald-600 h-full" style="width: ${{prog}}%"></div>
                                </div>
                            </div>
                        </td>
                        <td class="py-2.5 px-3 text-center">
                            <a href="${{link}}" target="_blank" class="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-900 font-bold underline text-xs">
                                <span>فتح الشواهد</span>
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                            </a>
                        </td>
                        <td class="py-2.5 px-3 text-center">
                            <button onclick="openQrModal('${{p.id}}')" class="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 font-bold text-xs">
                                عرض QR
                            </button>
                        </td>
                    </tr>
                `;
            }}).join('');
        }}

        // ===================== PROGRESS UPDATE =====================
        function updateProgramProgress(id, newProgress) {{
            const prog = programsData.find(p => p.id === id);
            if (prog) {{
                prog.progress = parseInt(newProgress);
                prog.status = prog.progress === 100 ? 'مكتمل' : (prog.progress > 0 ? 'جارٍ التنفيذ' : 'لم يبدأ');
                saveData();
                renderKPIs();
                renderLeadsVisual();
                renderExecutorsChart();
                showToast(`تم تحديث نسبة إنجاز ${{prog.name}} إلى ${{newProgress}}%`);
            }}
        }}

        // ===================== QR CODE & LINK MODAL =====================
        function openQrModal(id) {{
            activeModalProgId = id;
            const prog = programsData.find(p => p.id === id);
            if (!prog) return;

            document.getElementById('modalProgramName').textContent = prog.name;
            document.getElementById('modalProgramId').textContent = `${{prog.id}} • ${{prog.executor}}`;
            document.getElementById('modalLinkInput').value = prog.barcode_link || '';

            generateQrCode(prog.barcode_link || `https://mawahib-taiba.edu.sa/evidence/${{prog.id}}`);
            document.getElementById('qrModal').classList.remove('hidden');
        }}

        function closeQrModal() {{
            document.getElementById('qrModal').classList.add('hidden');
            activeModalProgId = null;
        }}

        function generateQrCode(url) {{
            const container = document.getElementById('qrcodeCanvas');
            container.innerHTML = '';
            try {{
                qrCodeInstance = new QRCode(container, {{
                    text: url,
                    width: 160,
                    height: 160,
                    colorDark: '#0f172a',
                    colorLight: '#ffffff',
                    correctLevel: QRCode.CorrectLevel.H
                }});
            }} catch(e) {{
                container.innerHTML = '<span class="text-xs text-red-500 font-bold">فشل توليد الباركود</span>';
            }}
        }}

        function saveModalLink() {{
            if (!activeModalProgId) return;
            const newLink = document.getElementById('modalLinkInput').value.trim();
            const prog = programsData.find(p => p.id === activeModalProgId);
            if (prog) {{
                prog.barcode_link = newLink;
                saveData();
                generateQrCode(newLink || `https://mawahib-taiba.edu.sa/evidence/${{prog.id}}`);
                renderProgramsList();
                showToast('تم حفظ وتحديث رابط الشواهد والباركود بنجاح');
            }}
        }}

        function openModalWebLink() {{
            const url = document.getElementById('modalLinkInput').value.trim();
            if (url) {{
                window.open(url, '_blank');
            }} else {{
                alert('يرجى إدخال رابط صالح أولاً');
            }}
        }}

        function downloadQrImage() {{
            const container = document.getElementById('qrcodeCanvas');
            const img = container.querySelector('img');
            const canvas = container.querySelector('canvas');
            
            let dataUrl = '';
            if (img && img.src) {{
                dataUrl = img.src;
            }} else if (canvas) {{
                dataUrl = canvas.toDataURL('image/png');
            }}

            if (dataUrl) {{
                const a = document.createElement('a');
                a.href = dataUrl;
                a.download = `QR_${{activeModalProgId}}_شواهد.png`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                showToast('تم تنزيل صورة الباركود بنجاح');
            }} else {{
                alert('تعذر استخراج صورة الباركود');
            }}
        }}

        // ===================== ADD NEW PROGRAM MODAL =====================
        function openAddProgramModal() {{
            document.getElementById('addProgramModal').classList.remove('hidden');
        }}

        function closeAddProgramModal() {{
            document.getElementById('addProgramModal').classList.add('hidden');
            document.getElementById('addProgramForm').reset();
        }}

        function submitNewProgram(e) {{
            e.preventDefault();
            const newId = 'PRG-' + String(programsData.length + 1).padStart(3, '0');
            const name = document.getElementById('newProgName').value.trim();
            const domain = document.getElementById('newProgDomain').value;
            const executor = document.getElementById('newProgExecutor').value.trim();
            const target = document.getElementById('newProgTarget').value.trim() || '95%';
            const supporter = document.getElementById('newProgSupporter').value.trim() || '';
            const link = document.getElementById('newProgLink').value.trim() || `https://mawahib-taiba.edu.sa/evidence/${{newId}}`;

            const newProgram = {{
                id: newId,
                name: name,
                domain: domain,
                executor: executor,
                supporter: supporter,
                target_kpi: target,
                start_date: '1448/03/17',
                end_date: '1448/12/30',
                status: 'لم يبدأ',
                progress: 0,
                barcode_link: link,
                detailed_goal: 'مبادرة مضافة حديثاً إلى الخطة التشغيلية'
            }};

            programsData.push(newProgram);
            saveData();
            closeAddProgramModal();
            renderDashboard();
            showToast(`تمت إضافة برنامج «${{name}}» بنجاح!`);
        }}

        // ===================== EXPORT TO CSV / EXCEL =====================
        function exportDataToCSV() {{
            let csvContent = "\\uFEFF";
            csvContent += "معرّف البرنامج,اسم البرنامج,المجال,مسؤول التنفيذ,الجهة المساندة,المستهدف,حالة التنفيذ,نسبة الإنجاز,رابط الشواهد\\n";

            programsData.forEach(p => {{
                const row = [
                    `"${{p.id}}"`,
                    `"${{(p.name || '').replace(/"/g, '""')}}"`,
                    `"${{(p.domain || '').replace(/"/g, '""')}}"`,
                    `"${{(p.executor || '').replace(/"/g, '""')}}"`,
                    `"${{(p.supporter || '').replace(/"/g, '""')}}"`,
                    `"${{(p.target_kpi || '').replace(/"/g, '""')}}"`,
                    `"${{p.status || 'لم يبدأ'}}"`,
                    `"${{p.progress || 0}}%"`,
                    `"${{p.barcode_link || ''}}"`
                ];
                csvContent += row.join(',') + '\\n';
            }});

            const blob = new Blob([csvContent], {{ type: 'text/csv;charset=utf-8;' }});
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'متابعة_الخطة_التشغيلية_ابتدائية_مواهب_طيبة.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showToast('تم تصدير ملف الإكسل (CSV) بنجاح');
        }}

        // ===================== TOAST SYSTEM =====================
        function showToast(msg) {{
            const toast = document.getElementById('toastBox');
            document.getElementById('toastMsg').textContent = msg;
            toast.classList.remove('translate-y-20', 'opacity-0');
            toast.classList.add('translate-y-0', 'opacity-100');
            setTimeout(() => {{
                toast.classList.add('translate-y-20', 'opacity-0');
                toast.classList.remove('translate-y-0', 'opacity-100');
            }}, 3000);
        }}
    </script>
</body>
</html>'''

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print('Generated clean and enhanced index.html successfully')
